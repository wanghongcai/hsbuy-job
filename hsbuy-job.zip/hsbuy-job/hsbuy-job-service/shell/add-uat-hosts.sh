echo '10.120.26.24  zk01.app.lenovo.com' >> /etc/hosts
echo '10.120.26.164 zk02.app.lenovo.com' >> /etc/hosts
echo '10.120.26.219 zk03.app.lenovo.com' >> /etc/hosts
