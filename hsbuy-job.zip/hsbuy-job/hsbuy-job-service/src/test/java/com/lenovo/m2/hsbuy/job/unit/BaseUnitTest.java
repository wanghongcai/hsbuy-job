package com.lenovo.m2.hsbuy.job.unit;

import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
        {
                "classpath:applicationContext-aop.xml",
                "classpath:applicationContext-dao.xml",
                "classpath:applicationContext-resources.xml",
                "classpath:applicationContext-dubbo-rpc.xml",
                "classpath:applicationContext-redis-shard.xml"
        }
) //加载配置文件
@Ignore
public class BaseUnitTest { 

}
