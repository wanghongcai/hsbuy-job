package com.lenovo.m2.hsbuy.job.order.workers;

import com.alibaba.fastjson.JSONArray;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.hsbuy.job.remote.SmbOrderServiceRemote;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/11/29 15:57
 */
public class SmbOrderProcessJob {

    private final static Logger LOGGER = LogManager.getLogger();
    private final String LOG_INFO_PREFIX = "SMB抛单审计日志-----";
    private final String LOG_ERROR_PREFIX = "SMB抛单异常日志====";


    @Autowired
    private SmbOrderServiceRemote smbOrderServiceRemote;

    @Value("${dynamic.env}")
    private String leconfEnv;

    /**
     * 抛 smb 订单
     */
    public void throwSmbOrderJob() {
        try {
            //获取smb待抛单列表
            RemoteResult<List<String>> result = smbOrderServiceRemote.getSmbThrowCustomerOrderCodes(leconfEnv);
            if (!result.isSuccess()) {
                LOGGER.error(LOG_ERROR_PREFIX + "throwSmbOrderJob error={}", result.getResultMsg());
                return;
            }

            List<String> customerOrderCodes = result.getT();
            LOGGER.info(LOG_INFO_PREFIX + "throwSmbOrderJob env={} 获取待抛单列表 size={}", leconfEnv, customerOrderCodes == null ? 0 : customerOrderCodes.size());
            LOGGER.info(LOG_INFO_PREFIX + "throwSmbOrderJob env={} 获取待抛单列表 customerOrderCodes={}",leconfEnv,((JSONArray)JSONArray.toJSON(customerOrderCodes)).toJSONString());

            //待抛单列表为空，直接返回
            if (CollectionUtils.isEmpty(customerOrderCodes)) {
                return;
            }

            ExecutorService smbExecutorService = Executors.newFixedThreadPool(3);

            try {
                int i=0;
                for(final String customerOrderCode : customerOrderCodes) {
                    LOGGER.info("待抛单编号customerOrderCode={},调用次数size={}",customerOrderCode,i++);
                    smbExecutorService.execute(new Runnable() {
                        @Override
                        public void run() {
                            LOGGER.info("待抛单编号customerOrderCode={}",customerOrderCode);
                            smbOrderServiceRemote.throwSmbOrderByCustomerOrderCode(customerOrderCode);
                        }
                    });
                }
            } catch(Exception e) {
                LOGGER.error("throwSmbOrderByCustomerOrderCode error", e);
            } finally {
                smbExecutorService.shutdown();
            }

            // awaitTermination返回false即超时会继续循环，返回true即线程池中的线程执行完成主线程跳出循环往下执行，每隔10秒循环一次
            while(!smbExecutorService.awaitTermination(10, TimeUnit.SECONDS)) {
            }

            LOGGER.info(LOG_INFO_PREFIX + " throwSmbOrderJob 抛单执行完成，执行订单 size={} ", customerOrderCodes.size());

        } catch(InterruptedException e) {
            LOGGER.error("throwSmbOrderJob error", e);
        }
    }

    /**
     * 抛 smb 支付信息（在线支付信息）
     */
    public void throwSmbPayInfoJob() {
        try {
            //获取smb待抛单列表
            RemoteResult<List<Long>> result = smbOrderServiceRemote.getSmbPayInfoOrderIds(leconfEnv);
            if (!result.isSuccess()) {
                LOGGER.error(LOG_ERROR_PREFIX + "throwSmbPayInfoJob error={}", result.getResultMsg());
                return;
            }

            List<Long> orderIds = result.getT();
            LOGGER.info(LOG_INFO_PREFIX + "throwSmbPayInfoJob env={} 获取已支付订单列表 size={}", leconfEnv, orderIds == null ? 0 : orderIds.size());
            LOGGER.info(LOG_INFO_PREFIX + "throwSmbPayInfoJob env={} 获取已支付订单列表 orderIds={}",leconfEnv,((JSONArray)JSONArray.toJSON(orderIds)).toJSONString());

            //待抛单列表为空，直接返回
            if (CollectionUtils.isEmpty(orderIds)) {
                return;
            }

            ExecutorService payExecutorService = Executors.newFixedThreadPool(3);

            try {
                int i=0;
                for(final Long orderId : orderIds) {
                    LOGGER.info("待支付订单编号orderIde={},调用次数size={}",orderId,i++);
                    payExecutorService.execute(new Runnable() {
                        @Override
                        public void run() {
                            LOGGER.info("待支付订单编号orderIde={}",orderId);
                            smbOrderServiceRemote.throwSmbPayInfoByOrderId(orderId);
                        }
                    });
                }
            } catch(Exception e) {
                LOGGER.error("throwSmbPayInfoByOrderId error", e);
            } finally {
                payExecutorService.shutdown();
            }


            // awaitTermination返回false即超时会继续循环，返回true即线程池中的线程执行完成主线程跳出循环往下执行，每隔10秒循环一次
            while(!payExecutorService.awaitTermination(10, TimeUnit.SECONDS)) {
            }

            LOGGER.info(LOG_INFO_PREFIX + " throwSmbPayInfoJob 抛单执行完成，执行订单 size={} ", orderIds.size());

        } catch(Exception e) {
            LOGGER.error("throwSmbPayInfoJob error", e);
        }


    }
}
