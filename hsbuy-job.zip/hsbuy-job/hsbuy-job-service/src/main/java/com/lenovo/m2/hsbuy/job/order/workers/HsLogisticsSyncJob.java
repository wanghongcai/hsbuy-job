package com.lenovo.m2.hsbuy.job.order.workers;

import com.lenovo.m2.hsbuy.job.remote.HsLogisticsSyncRemote;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/11/29 16:05
 */
public class HsLogisticsSyncJob {
    private final static Logger LOGGER = LogManager.getLogger();

    @Autowired
    private HsLogisticsSyncRemote hsLogisticsSyncRemote;


    /**
     * 惠商地址同步
     *
     * @return
     */
    public void hsLogisticsSyncTask() {
        try {
            hsLogisticsSyncRemote.hsLogisticsSyncTask();
        } catch(Exception e) {
            LOGGER.error("hsLogisticsSyncTask error", e);
        }
    }

}
