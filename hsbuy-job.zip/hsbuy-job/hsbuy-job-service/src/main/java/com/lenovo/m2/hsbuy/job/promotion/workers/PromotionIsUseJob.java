package com.lenovo.m2.hsbuy.job.promotion.workers;

import com.lenovo.m2.hsbuy.job.promotion.service.PromotionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by luqian on 2015-12-07.
 */
public class PromotionIsUseJob {
    private static final Logger logger = LoggerFactory.getLogger(PromotionIsUseJob.class);
    @Autowired
    private PromotionService promotionService;

    public void updatePromotionIsUse() {
        logger.info("执行促销是否启用定时任务");
        promotionService.updatePromotionIsUse();
    }
}
