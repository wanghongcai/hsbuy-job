package com.lenovo.m2.hsbuy.job.order.service;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.job.domain.order.HsAuditInfo;

/**
 * <pre>
 *    author  : licy13
 *    email   : licy13@lenovo.com
 *    time    : 2017/9/27 18:28
 *    desc    : 扫单服务
 *    version : v1.0
 * </pre>
 */
public interface ScanOrderService {


    /**
     * 根据订单号保存扫单记录
     *
     * @param orderId
     */
    public RemoteResult saveScanOrderRecord(Long orderId);

    /**
     * 根据订单号 更新支付回调的 扫单状态
     *
     * @param orderId
     * @return
     */
    public RemoteResult updatePaidCallbackOrderScanStatus(Long orderId);


    /**
     * 更新惠商审单信息
     *
     * @param hsAuditInfo
     * @return
     */
    public RemoteResult updateHsAuditInfo(HsAuditInfo hsAuditInfo);


}
