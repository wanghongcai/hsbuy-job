package com.lenovo.m2.hsbuy.job.order.service.kafka;

import com.alibaba.fastjson.JSONObject;
import com.lenovo.m2.hsbuy.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.domain.middleware.ShopIdsEnum;
import com.lenovo.m2.hsbuy.domain.order.FirstOrderCode;
import com.lenovo.m2.hsbuy.job.domain.order.HsAuditInfo;
import com.lenovo.m2.hsbuy.job.order.service.ScanOrderService;
import kafka.consumer.ConsumerIterator;
import kafka.consumer.KafkaStream;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.util.List;

public class MessageScanConsumer implements Runnable {
    private KafkaStream<byte[], byte[]> m_stream;
    private int m_threadNumber;
    private ScanOrderService scanOrderService;
    private String topic;
    private Logger logger = Logger.getLogger(MessageScanConsumer.class);

    public MessageScanConsumer(KafkaStream<byte[], byte[]> m_stream, int m_threadNumber, String topic, ScanOrderService scanOrderService) {
        this.m_stream = m_stream;
        this.m_threadNumber = m_threadNumber;
        this.topic = topic;
        this.scanOrderService = scanOrderService;
    }

    public void run() {
        ConsumerIterator<byte[], byte[]> it = m_stream.iterator();
        while(it.hasNext()) {
            StringBuilder message = new StringBuilder();
            message.append("Thread ").append(m_threadNumber).append(" is consuming topic[").append(topic).append("] ");
            String kafkaInfo = new String(it.next().message());
            try {
                logger.info(message.append(" the message is: ").append(kafkaInfo));

                //一拆订单
                if (StringUtils.equals(topic, "firstOrderCode")) {
                    List<FirstOrderCode> codes = JsonUtil.readValuesAsArrayList(kafkaInfo, FirstOrderCode.class);
                    for(FirstOrderCode firstOrderCode : codes) {
                        //惠商入库
                        if (ShopIdsEnum.isHuiShang(firstOrderCode.getShopId())) {
                            scanOrderService.saveScanOrderRecord(firstOrderCode.getOrderCode());
                        }
                    }
                }
                //惠商审单
                if (StringUtils.equals(topic, "auditContract")) {
                    scanOrderService.updateHsAuditInfo(getHsAudit(kafkaInfo));
                }

            } catch(Exception e) {
                logger.error(message.append("catch exception."), e);
            }
        }
    }

    private HsAuditInfo getHsAudit(String kafkaInfo) {
        JSONObject jsonObject = JSONObject.parseObject(kafkaInfo);
        HsAuditInfo hsAuditInfo = new HsAuditInfo();
        hsAuditInfo.setShopId(jsonObject.getInteger("shopId"));
        hsAuditInfo.setOrderCode(jsonObject.getLong("orderCode"));
        hsAuditInfo.setPass(jsonObject.getBoolean("pass"));
        hsAuditInfo.setAuditTime(jsonObject.getString("AuditTime"));
        return hsAuditInfo;
    }

}
