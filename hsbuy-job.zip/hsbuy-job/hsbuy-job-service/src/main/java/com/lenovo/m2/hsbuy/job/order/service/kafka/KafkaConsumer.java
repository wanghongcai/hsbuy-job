package com.lenovo.m2.hsbuy.job.order.service.kafka;


import com.lenovo.m2.hsbuy.job.order.service.ScanOrderService;
import kafka.consumer.Consumer;
import kafka.consumer.ConsumerConfig;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * update by licy13 on 2017/5/12
 */
public class KafkaConsumer {
    private static Logger LOGGER = LogManager.getLogger(KafkaConsumer.class.getName());


    private String type;
    private String topicName;
    private String groupName;
    private ExecutorService executor;
    private KafkaConsumerOptions options;
    private ConsumerConnector connector;

    @Autowired
    private ScanOrderService scanOrderService;

    public KafkaConsumer(KafkaConsumerOptions kafkaConsumerOption, String topicName, String groupName, String type) {
        this.options = kafkaConsumerOption;
        this.topicName = topicName;
        this.groupName = groupName;
        this.type = type;
    }

    public KafkaConsumer() {

    }

    public void initialize() {
        Properties props = new Properties();
        props.put("zookeeper.connect", this.options.getConnectionZk());
        props.put("group.id", this.groupName);
        props.put("zookeeper.session.timeout.ms", this.options.getZkSessionTimeout());
        props.put("zookeeper.sync.time.ms", this.options.getZkSyncTime());
        props.put("auto.commit.interval.ms", this.options.getAutoCommitInterval());
        props.put("rebalance.backoff.ms", this.options.getRebalanceBackOff());
        props.put("rebalance.max.retries", this.options.getRebalanceMaxRetries());
        props.put("auto.offset.reset", this.options.getAutoOffsetReset());
        ConsumerConfig config = new ConsumerConfig(props);
        this.connector = Consumer.createJavaConsumerConnector(config);
    }


    /**
     * 多线程消费，建议和partition数量一致
     */
    public void run(int partitionNum) {
        Map<String, Integer> topicCountMap = new HashMap<String, Integer>();
        topicCountMap.put(topicName, new Integer(partitionNum));// 描述读取哪个topic，需要几个线程读
        Map<String, List<KafkaStream<byte[], byte[]>>> consumerMap = connector.createMessageStreams(topicCountMap);// 创建Streams
        List<KafkaStream<byte[], byte[]>> streams = consumerMap.get(topicName);// 每个线程对应于一个KafkaStream
        // now launch all the threads
        executor = Executors.newFixedThreadPool(streams.size());
        // now create an object to consume the messages
        int threadNumber = 0;
        try {
            for(final KafkaStream stream : streams) {
                //MIDDLEWARE、PIPELINE
                //scan 扫单处理
                executor.submit(new MessageScanConsumer(stream, threadNumber, topicName, scanOrderService));
                threadNumber++;
            }
        } catch(Exception e) {
            LOGGER.error("Run message consumer catch Exception. " + e);
        }

    }

    public void shutdown() {
        LOGGER.info("KafkaConsumer shutdown topicName={}", topicName);
        if (connector != null) connector.shutdown();
        if (executor != null) executor.shutdown();
        try {
            if (!executor.awaitTermination(5000, TimeUnit.MILLISECONDS)) {
                LOGGER.info("KafkaConsumer shutdown: Timed out waiting for consumer threads to shut down, exiting uncleanly");
            }
        } catch(InterruptedException e) {
            LOGGER.info("KafkaConsumer shutdown: Interrupted during shutdown, exiting uncleanly");
        }
    }

}