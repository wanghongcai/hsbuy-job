package com.lenovo.m2.hsbuy.job.order.service;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

import java.util.List;

/**
 * <pre>
 *    author  : licy13
 *    email   : licy13@lenovo.com
 *    time    : 2017/9/30 10:08
 *    desc    : 扫单对外开发的 api接口
 *    version : v1.0
 * </pre>
 */
public interface ScanOrderApiService {

    /**
     * 获取待扫单订单号
     *
     * @param env
     * @return
     */
    public RemoteResult<List<Long>> queryHsScanOrderIds(String env);

    /**
     * 根据订单号扫单
     *
     * @param orderId
     */
    public RemoteResult scanOrderByOrderId(Long orderId);

    /**
     * 根据订单号列表批量扫单
     *
     * @param orderIds
     */
    public void scanOrderByOrderIds(List<Long> orderIds);


}
