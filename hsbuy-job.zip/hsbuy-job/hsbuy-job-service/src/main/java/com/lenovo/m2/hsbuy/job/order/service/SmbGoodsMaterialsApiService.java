package com.lenovo.m2.hsbuy.job.order.service;

/**
 * <pre>
 *    author  : licy13
 *    email   : licy13@lenovo.com
 *    time    : 2017/9/30 10:40
 *    version : v1.0
 * </pre>
 */
public interface SmbGoodsMaterialsApiService {

    /**
     * 转移smb 商品物料
     */
    public void transferSmbGoodsMaterials();

    /**
     * 转移smb 增量商品物料
     */
    public void transferSmbGoodsMaterialsByCreateTime();
}
