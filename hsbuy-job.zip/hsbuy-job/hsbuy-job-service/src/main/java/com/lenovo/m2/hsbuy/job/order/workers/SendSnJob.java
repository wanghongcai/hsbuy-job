package com.lenovo.m2.hsbuy.job.order.workers;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.hsbuy.job.remote.SendSnRemote;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;
import com.lenovo.m2.hsbuy.domain.throwengine.SmbSendSn;

/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/12/21 18:13
 */
public class SendSnJob {

    private final static Logger LOGGER = LogManager.getLogger();

    @Autowired
    private SendSnRemote sendSnRemote;


    @Value("${dynamic.env}")
    private String leconfEnv;


    public void sendSn() {
        try {
            LOGGER.info("---------sn 同步 start ---------");

            // 订单 数据 同步到 临时表
            sendSnRemote.getAndSaveSmbSn();

            // 与 smb 同步 sn
            //获取待扫单列表
            RemoteResult<List<SmbSendSn>> result = sendSnRemote.querySmbSn(leconfEnv);
            if (!result.isSuccess()) {
                LOGGER.error("sendSn error={}", result.getResultMsg());
                return;
            }

            List<SmbSendSn> smbSendSns = result.getT();
            LOGGER.info("sendSn env={} 获取待同步列表 size={}", leconfEnv, smbSendSns == null ? 0 : smbSendSns.size());

            //待扫单列表为空，直接返回
            if (CollectionUtils.isEmpty(smbSendSns)) {
                return;
            }


            try {
                for(final SmbSendSn smbSendSn : smbSendSns) {
                    sendSnRemote.sendSn(smbSendSn);
                }
            } catch(Exception e) {
                LOGGER.error("scanOrderByOrderId error", e);
            }

            LOGGER.info(" sendSn 扫单执行完成，执行订单 size={} ", smbSendSns.size());

        } catch(Exception e) {
            LOGGER.error("sendSn error", e);
        }
    }
}
