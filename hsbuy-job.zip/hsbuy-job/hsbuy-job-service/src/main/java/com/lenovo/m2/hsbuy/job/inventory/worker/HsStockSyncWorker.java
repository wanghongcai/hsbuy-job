package com.lenovo.m2.hsbuy.job.inventory.worker;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.lenovo.common.base.PageMap;
import com.lenovo.fis.model.FaBaseInfoes;
import com.lenovo.fis.model.GoodsMaterials;
import com.lenovo.m2.hsbuy.domain.inventory.StockInfo;
import com.lenovo.m2.hsbuy.inventory.HsStockApiService;
import com.lenovo.m2.hsbuy.job.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.job.inventory.service.StockService;
import com.lenovo.shop.admin.api.FaBaseInfoesService;
import com.lenovo.shop.goods.api.GoodsMaterialsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 每小时获取一次上架状态的惠商在线库存，然后根据faid、分销商编号、物料号去同步惠商SEC和自有库存
 * Created by yezhenyue on 2017/3/10.
 */
public class HsStockSyncWorker {
    private static final Logger LOGGER = LoggerFactory.getLogger(HsStockSyncWorker.class);
    @Autowired
    private StockService stockService;
    @Autowired
    private HsStockApiService hsStockApiService;
    @Autowired
    private FaBaseInfoesService faBaseInfoesService;
    @Autowired
    private GoodsMaterialsService goodsMaterialsService;

    public void execute(){
                LOGGER.info("----- HsStockSyncWorker start ------------------");
                try {
                    //查询shoid=14(惠商)并且上架的库存列表
                        List<StockInfo> hsStockList = stockService.getHsOnlineStock();
                        if (hsStockList != null) {
                            Map<String,List<GoodsMaterials>> map = new HashMap<String, List<GoodsMaterials>>();
                            //将库存按faid整理到map中 每个faid对应一个物料对象列表
                            for (StockInfo stockInfo : hsStockList) {
                                String faid = stockInfo.getFaid();
                                String goodsCode = stockInfo.getGoodsCode();//官网物料
                                Integer proatt = stockInfo.getProatt();//物料类型 1=联想物料 2=非联想物料 3=惠商CTO物料
                                GoodsMaterials goodsMaterials = new GoodsMaterials();
                                goodsMaterials.setLenovoMaterialNumber(goodsCode);
                                if (proatt!=null && proatt==3){//如果是惠商CTO 调物料接口获取SEC真实物料和TMS单号
                                    GoodsMaterials materials = goodsMaterialsService.getMaterialByNumber(goodsCode);
                                    LOGGER.info("GoodsMaterials:"+ JsonUtil.toJson(materials));
                                    goodsMaterials.setMaterialExtend(materials.getMaterialExtend());
                                    goodsMaterials.setRealMaterialNumber(materials.getRealMaterialNumber());
                                }
                                if (map.get(faid) == null) {
                                    List<GoodsMaterials> temp = new ArrayList<GoodsMaterials>();
                                    temp.add(goodsMaterials);
                                    map.put(faid, temp);
                                } else {
                                    List<GoodsMaterials> temp = map.get(faid);
                                    temp.add(goodsMaterials);
                                }
                            }
                            //遍历map 根据faid获取分销商编号，然后遍历该faid对应的物料编号列表 同步分销商库存
                            for (Map.Entry<String, List<GoodsMaterials>> entry : map.entrySet()) {
                                String faid = entry.getKey();
                                List<GoodsMaterials> materialsList = entry.getValue();
                                String fxsNo = getFxsNo(faid);//根据fa主键id获取分销商编号
                                if (fxsNo == null) {
                                    LOGGER.error("获取分销商编号失败！faid=" + faid);
                                    continue;
                                }
                                //同步惠商SEC和自有库存
                                LOGGER.info("同步start---faid:"+faid+",fxsno:"+fxsNo+",materialsList"+JsonUtil.toJson(materialsList));
                                hsStockApiService.syncHsStock(faid, fxsNo, materialsList);
                                LOGGER.info("同步end-------------------");
                            }
                    }
                }catch (Exception e){
                    LOGGER.error(e.getMessage(),e);
                }
                LOGGER.info("----- HsStockSyncWorker end ------------------");
            }
    //根据fa主键id获取分销商编号
    private String getFxsNo(String faid){
        String fxsNo = null;
        PageMap pageMap = new PageMap();
        pageMap.putSelectParams("id", faid);
        PageMap resultMap = faBaseInfoesService.PageQuery(pageMap);
        List<FaBaseInfoes> pageList = (List<FaBaseInfoes>) resultMap.getPageList();
        if (CollectionUtils.isNotEmpty(pageList)) {
            FaBaseInfoes faBaseInfoes = pageList.get(0);
            fxsNo = faBaseInfoes.getFaid();
        }
        return fxsNo;
    }

}
