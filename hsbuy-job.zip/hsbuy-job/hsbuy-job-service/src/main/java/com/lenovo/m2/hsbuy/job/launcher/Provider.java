package com.lenovo.m2.hsbuy.job.launcher;

import com.lenovo.m2.hsbuy.job.order.service.kafka.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by fenglg1 on 2015/5/19.
 */
public class Provider {

    private static Logger logger = LoggerFactory.getLogger(Provider.class);

    private static volatile boolean running = true;
    private static ApplicationContext ctx;

    public static void main(String[] args) {
        try {

            ctx = new ClassPathXmlApplicationContext(
                    new String[]{
                            "applicationContext-resources.xml",
                            "applicationContext-dao.xml",
                            "applicationContext-dubbo-rpc.xml",
                            "applicationContext-quartz.xml",
                            "applicationContext-order-quartz.xml",
                            "applicationContext-redis-shard.xml",
                            "kafka-consumer.xml"
                    }
            );

            logger.info(new SimpleDateFormat("[yyyy-MM-dd HH:mm:ss]").format(new Date()) + " Dubbo job server started!");
            ExecutorService executorService = Executors.newFixedThreadPool(2);
            try {
                executorService.submit(new Runnable() {
                    @Override
                    public void run() {
                        KafkaConsumer kafkaConsumer = (KafkaConsumer) ctx.getBean("kafkaConsumerFirstPipeline");
                        kafkaConsumer.run(3);
                    }
                });
                executorService.submit(new Runnable() {
                    @Override
                    public void run() {
                        KafkaConsumer kafkaConsumer = (KafkaConsumer) ctx.getBean("kafkaConsumerHSAuditOrder");
                        kafkaConsumer.run(3);
                    }
                });
            } finally {
                executorService.shutdown();
            }
        } catch(Exception e) {
            logger.error(e.getMessage(), e);
            running = false;
            logger.error(e.getMessage(), e);
        }

        synchronized(Provider.class) {
            while(running) {
                try {
                    Provider.class.wait();
                } catch(Exception e) {
                }
            }
        }
    }
}
