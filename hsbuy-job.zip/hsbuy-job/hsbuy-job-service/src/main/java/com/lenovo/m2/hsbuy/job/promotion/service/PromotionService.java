package com.lenovo.m2.hsbuy.job.promotion.service;

/**
 * Created by luqian on 2015-12-05.
 */
public interface PromotionService {
     public void updatePromotionIsUse();

}
