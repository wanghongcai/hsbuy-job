package com.lenovo.m2.hsbuy.job.order.workers;

import com.lenovo.m2.hsbuy.job.order.service.SmbGoodsMaterialsApiService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by zhaocl1 on 2016/8/17.
 */
public class SmbGoodsMaterialsJob {

    private static final Logger log = Logger.getLogger(SmbGoodsMaterialsJob.class);

    @Autowired
    private SmbGoodsMaterialsApiService smbGoodsMaterialsApiService;

    public void transferSmbGoodsMaterials() {
        log.info("---------转移物料开始 start ");
        long starttime = System.currentTimeMillis();
        smbGoodsMaterialsApiService.transferSmbGoodsMaterials();
        log.info("---------转移物料开始 end 花费时间：" + (System.currentTimeMillis() - starttime) + "ms");
    }

    public void transferSmbGoodsMaterialsByCreateTime() {
        log.info("---------转移增量物料开始 start ");
        long starttime = System.currentTimeMillis();
        smbGoodsMaterialsApiService.transferSmbGoodsMaterialsByCreateTime();
        log.info("---------转移增量物料开始 end 花费时间：" + (System.currentTimeMillis() - starttime) + "ms");
    }
}
