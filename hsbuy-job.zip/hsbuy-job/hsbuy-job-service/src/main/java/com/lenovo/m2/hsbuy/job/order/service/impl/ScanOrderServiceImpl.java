package com.lenovo.m2.hsbuy.job.order.service.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderMain;
import com.lenovo.m2.hsbuy.job.common.order.ScanOrderConstant;
import com.lenovo.m2.hsbuy.job.common.order.enums.ResultMessageEnum;
import com.lenovo.m2.hsbuy.job.common.order.enums.ShopIdsEnum;
import com.lenovo.m2.hsbuy.job.common.order.utils.JsonMUtil;
import com.lenovo.m2.hsbuy.job.common.order.utils.RemoteResultFactory;
import com.lenovo.m2.hsbuy.job.domain.order.HsAuditInfo;
import com.lenovo.m2.hsbuy.job.domain.order.ScanOrder;
import com.lenovo.m2.hsbuy.job.manager.order.pipeline.MOrderMainManager;
import com.lenovo.m2.hsbuy.job.manager.order.pipeline.ScanOrderManager;
import com.lenovo.m2.hsbuy.job.order.service.ScanOrderApiService;
import com.lenovo.m2.hsbuy.job.order.service.ScanOrderService;
import com.lenovo.m2.hsbuy.job.remote.MiddleWareRemote;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <pre>
 *    author  : licy13
 *    email   : licy13@lenovo.com
 *    time    : 2017/9/27 18:29
 *    desc    : 扫单服务
 *    version : v1.0
 * </pre>
 */
@Service("scanOrderService")
public class ScanOrderServiceImpl implements ScanOrderService, ScanOrderApiService {

    private final static Logger LOGGER = LogManager.getLogger();

    @Autowired
    private ScanOrderManager scanOrderManager;
    @Autowired
    private MOrderMainManager mOrderMainManager;
//    @Autowired
//    private PayRemote payRemote;
    @Autowired
    private MiddleWareRemote middleWareRemote;
    /**
     * @Param leconfEnv leconf配置环境变量
     */
    @Value("${dynamic.env}")
    private String leconfEnv;

    /**
     * @Param hsSilentMinutesTime 惠商静默订单 未付款 扫单时间
     */
    @Value("${scanorder.hs.silent.minutes}")
    private int hsSilentMinutesTime;


    /**
     * @Param hsAuditMinutesTime 惠商审核通过 未付款 扫单时间
     */
    @Value("${scanorder.hs.audit.minutes}")
    private int hsAuditMinutesTime;

    /**
     * @Param hsUnauditedMinutesTime 惠商未审核订单 扫单时间
     */
    @Value("${scanorder.hs.unaudited.minutes}")
    private int hsUnauditedMinutesTime;


    /**
     * 获取待扫单订单号
     *
     * @param env
     * @return
     */
    @Override
    public RemoteResult queryHsScanOrderIds(String env) {
        //静默订单

        List<Long> result = new ArrayList<>(50);
        RemoteResult<List<Long>> unAuditResult = scanOrderManager.queryHsUnAuditScanOrderIds(hsUnauditedMinutesTime, env);
        if (unAuditResult.isSuccess()) {
            List<Long> list = unAuditResult.getT();
            if (CollectionUtils.isNotEmpty(list)) {
                LOGGER.info("----- [HS] 未审核 待扫单数量[{}]...扫{}分钟之前未支付订单,env={}", list.size(), hsUnauditedMinutesTime, env);
                result.addAll(list);
            }
        }
        RemoteResult<List<Long>> auditResult = scanOrderManager.queryHsAuditScanOrderIds(hsAuditMinutesTime, env);
        if (auditResult.isSuccess()) {
            List<Long> list = auditResult.getT();
            if (CollectionUtils.isNotEmpty(list)) {
                LOGGER.info("----- [HS] 审核通过未支付 待扫单数量[{}]...扫{}分钟之前未支付订单,env={}", list.size(), hsAuditMinutesTime, env);
                result.addAll(list);
            }
        }
        RemoteResult<List<Long>> silentResult = scanOrderManager.queryHsSilentScanOrderIds(hsSilentMinutesTime, env);
        if (silentResult.isSuccess()) {
            List<Long> list = silentResult.getT();
            if (CollectionUtils.isNotEmpty(list)) {
                LOGGER.info("----- [HS] 静默订单未支付 待扫单数量[{}]...扫{}分钟之前未支付订单,env={}", list.size(), hsSilentMinutesTime, env);
                result.addAll(list);
            }
        }
        return RemoteResultFactory.getSuccessResult(result);
    }


    /**
     * 根据订单号扫单
     *
     * @param orderId
     */
    @Override
    public RemoteResult scanOrderByOrderId(Long orderId) {

        //获取一拆订单信息
        RemoteResult<MOrderMain> mOrderMainResult = mOrderMainManager.getMOrderMainByOrderCode(orderId);
        if (!mOrderMainResult.isSuccess()) {
            return mOrderMainResult;
        }

        MOrderMain mOrderMain = mOrderMainResult.getT();
        if (mOrderMain == null) {
            LOGGER.error("scanOrderByOrderId getMOrderMainByOrderId 未查到订单信息 orderId={}", orderId);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR_EMPTY_ORDER);
        }

        //如果订单已经取消
        if (mOrderMain.getOrderStatus() == ScanOrderConstant.ORDER_STATUS_CANCEL) {
            scanOrderManager.updateScanOrderStatus(orderId, ScanOrderConstant.SCAN_STAUTS_SUCCESS);
            return RemoteResultFactory.getSuccessResult();
        }

        //如果订单已经支付
        if (mOrderMain.getPayStatus() == ScanOrderConstant.PAY_STATUS_PAID) {
            scanOrderManager.updateScanOrderStatus(orderId, ScanOrderConstant.SCAN_STAUTS_PAID);
            return RemoteResultFactory.getSuccessResult();
        }

//        //调用支付服务
//        RemoteResult payCancelOrder = payRemote.askForPayCancelOrder(orderId, Tenant.getTenant(mOrderMain.getShopId()));
//
//        //==支付系统返回 不允许扫单
//        if (!payCancelOrder.isSuccess()) {
//            //更新已支付--挂起
//            scanOrderManager.updatePayOrderScanStatus(orderId, payCancelOrder.getResultCode(), payCancelOrder.getResultMsg());
//            return RemoteResultFactory.getSuccessResult();
//
//        }

        //==支付系统返回 允许扫单

        //更新扫单中...状态
        RemoteResult<Integer> pendingStatusResult = scanOrderManager.updateScanOrderPendingStatus(orderId);
        if (!pendingStatusResult.isSuccess()) {
            return pendingStatusResult;
        }

        //更新扫单中...状态失败，中止扫单
        if (pendingStatusResult.getT() == 0) {
            LOGGER.info("scanOrderByOrderId updateScanOrderPendingStatus 更新扫单中状态 返回更新 0 条数据，中止扫该单 orderId={}", orderId);
            return RemoteResultFactory.getSuccessResult();
        }

        //调用中间件 扫单
        RemoteResult cancelOrderResult = middleWareRemote.cancelOrder(orderId, ScanOrderConstant.CANCEL_TYPE_SCAN_ORDER, mOrderMain.getShopId());

        //==取消订单成功
        if (cancelOrderResult.isSuccess()) {
            //更新扫单成功
            return scanOrderManager.updateScanOrderSuccessStatus(orderId);
        }

        //==取消订单未成功

        //如果 中间件取消订单 返回已支付
        if (ScanOrderConstant.ORDER_PAID.equals(cancelOrderResult.getResultCode())) {
            //更新已支付--挂起
            scanOrderManager.updatePayOrderScanStatus(orderId, cancelOrderResult.getResultCode(), cancelOrderResult.getResultMsg());
            return RemoteResultFactory.getSuccessResult();
        }

        //更新 待扫单状态--次数 + 1
        scanOrderManager.updateScanOrderFailStatus(orderId, cancelOrderResult.getResultCode(), cancelOrderResult.getResultMsg());
        return RemoteResultFactory.getSuccessResult();


    }

    /**
     * 根据订单号列表批量扫单
     *
     * @param orderIds
     */
    @Override
    public void scanOrderByOrderIds(List<Long> orderIds) {
        LOGGER.info("scanOrderByOrderIds params orderId={}", JsonMUtil.toJson(orderIds));
        for(Long orderId : orderIds) {
            RemoteResult result = this.scanOrderByOrderId(orderId);
            if (!result.isSuccess()) {
                LOGGER.error("scanOrderByOrderIds orderId={}, result={}", orderId, JsonMUtil.toJson(result));
            }
        }
    }

    /**
     * 根据订单号保存扫单记录
     *
     * @param orderId
     */
    @Override
    public RemoteResult saveScanOrderRecord(Long orderId) {

        //获取一拆订单信息
        RemoteResult<MOrderMain> mOrderMainResult = mOrderMainManager.getMOrderMainByOrderCode(orderId);
        if (!mOrderMainResult.isSuccess()) {
            return mOrderMainResult;
        }

        MOrderMain mOrderMain = mOrderMainResult.getT();
        if (mOrderMain == null) {
            LOGGER.error("scanOrderByOrderId getMOrderMainByOrderId 未查到订单信息 orderId={}", orderId);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR_EMPTY_ORDER);
        }

        //惠商的线下银行转账 不扫单
        if (ShopIdsEnum.isHuiShang(mOrderMain.getShopId()) && ScanOrderConstant.ORDER_PAYMENT_OFFLINE_TYPE == mOrderMain.getPaymentTypeId()) {
            LOGGER.info("惠商线下银行转账订单 不扫单，不进扫单表 orderId={}", orderId);
            return RemoteResultFactory.getSuccessResult();
        }

        //组装 扫单记录 保存记录
        ScanOrder scanOrder = new ScanOrder();
        scanOrder.setOrderId(mOrderMain.getOrderCode());
        scanOrder.setLenovoId(mOrderMain.getLenovoId());
        scanOrder.setOrderType(mOrderMain.getOrderType());
        scanOrder.setPaymentType(mOrderMain.getPaymentTypeId());
        scanOrder.setOrderTime(mOrderMain.getCreateTime());
        scanOrder.setEnv(System.getenv("ENV"));
        scanOrder.setShopId(mOrderMain.getShopId());
        scanOrder.setCreateTime(DateFormatUtils.parseDate(new Date()));
        //需要不同商城转换一下
        scanOrder.setSubmitOrderWay(mOrderMain.getSubmitOrderWay());

        return scanOrderManager.saveScanOrderRecord(scanOrder);
    }

    /**
     * 根据订单号更新支付订单号扫单状态
     *
     * @param orderId
     * @return
     */
    @Override
    public RemoteResult updatePaidCallbackOrderScanStatus(Long orderId) {
        LOGGER.info("updatePaidCallbackOrderScanStatus params orderId={}", orderId);
        return scanOrderManager.updatePaidCallbackOrderScanStatus(orderId);
    }

    /**
     * 更新惠商审单信息
     *
     * @param hsAuditInfo
     * @return
     */
    @Override
    public RemoteResult updateHsAuditInfo(HsAuditInfo hsAuditInfo) {
        LOGGER.info("updateHsAuditInfo params hsAuditInfo={}", hsAuditInfo);

        //兼容：之前没有审核时间
        if (hsAuditInfo != null && StringUtils.isEmpty(hsAuditInfo.getAuditTime())) {
            hsAuditInfo.setAuditTime(DateFormatUtils.format(new Date()));
        }

        if (hsAuditInfo == null || !ShopIdsEnum.isLegalShopId(hsAuditInfo.getShopId()) || DateFormatUtils.parseDate(hsAuditInfo.getAuditTime()) == null) {
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR_PARAM);
        }
        return scanOrderManager.updateHsAuditInfo(hsAuditInfo);
    }
}
