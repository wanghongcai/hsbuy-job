package com.lenovo.m2.hsbuy.job.address.work;

import com.lenovo.m2.hsbuy.job.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.job.dao.address.SmbAddressMapper;
import com.lenovo.m2.hsbuy.job.domain.address.SmbAddress;
import com.lenovo.m2.hsbuy.job.domain.address.TreeNode;
import com.lenovo.m2.hsbuy.job.redis.MyRedisConn;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.dbutils.BasicRowProcessor;
import org.apache.commons.dbutils.BeanProcessor;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by admin on 2017/11/27.
 */
public class SMBSyncAreaAddressWorker {
    private static final Logger LOGGER = LoggerFactory.getLogger(SMBSyncAreaAddressWorker.class);

    //惠商同步四级地址数据库url
    private String url;
    //惠商同步四级地址数据库用户名
    private String username;
    //惠商同步四级地址数据库密码
    private String password;
    //连接数据库ClassName
    private String driveClassName;
    //全国树，只有省信息
    private static final String SMB_ADDRESS_All_TREE_REDIS = "smb_address_all_tree_redis";
    //每个省一个树，包含市，区县，乡镇信息
    private static final String SMB_ADDRESS_PROVINCE_TREE_REDIS = "smb_address_province_tree_redis";


    @Autowired
    private SmbAddressMapper smbAddressMapper;
    @Autowired
    private MyRedisConn myRedisConn;

    public void execute(){
        try {
            reloadAreaAddress();
            LOGGER.info("SMBSyncAreaAddressWorker==执行成功");
        }catch (Exception e){
            LOGGER.info("SMBSyncAreaAddressWorker==出现异常=="+e.getMessage(),e);
        }
    }

    /**
     * 从smb数据库读取最新的省市区县信息，更新自己的数据库
     */
    private void reloadAreaAddress() {
        //获取smb最新数据库四级地址信息
        boolean flag = false;
        //List<SmbAddress> list = smbAddressSyncMapper.getAllFourLevelSmbAddress();
        List<SmbAddress> list = getAllFourLevelSmbAddress();
        if(null != list && list.size() >0){
            LOGGER.info("smb==reloadAreaAddress==获取到的smb四级地址条数=="+list.size());
            int t = smbAddressMapper.deleteFourLevelSmbAddress();
            LOGGER.info("smb==reloadAreaAddress==删除的smb四级地址条数=="+t);
            //查询成功，并且删除成功，将最新的数据插入到数据库中
            if(t>0){
                //分批保存
                int mod = list.size()%100 == 0 ? list.size()/100:list.size()/100+1;
                int temp=0;
                for(int i=0;i<mod;i++){
                    if(i == mod-1){
                        List<SmbAddress> sub = list.subList(i*100, list.size());
                        temp += smbAddressMapper.initBatchInsertFourLevelAddress(sub);
                    }else{
                        List<SmbAddress> sub = list.subList(i*100, i*100+100);
                        temp += smbAddressMapper.initBatchInsertFourLevelAddress(sub);
                    }
                }
                LOGGER.info("smb==reloadAreaAddress==新插入的smb四级地址条数=="+temp);
                //新数据插入成功才进行初始化
                if(temp >0){
                    initData();
                }
            }
        }
    }

    /**
     * 初始化redis中数据
     */
    private void initData() {
        LOGGER.info("smb==执行了initData！");
        List<SmbAddress> list = smbAddressMapper.getAll();
        if (CollectionUtils.isNotEmpty(list)) {
            //存储所有省信息
            List<SmbAddress> provinces = new ArrayList<>(35);
            //存储所有省名称
            Set<String> provinceNames = new HashSet<>();
            //存储所有市信息
            List<SmbAddress> cities = new ArrayList<>();
            //存储所有市名称
            Set<String> cityNames = new HashSet<>();
            //存储所有区县信息
            List<SmbAddress> counties = new ArrayList<>();
            //存储所有区县名称
            Set<String> countyNames = new HashSet<>();
            //list中的数据就是所有乡镇
            for (SmbAddress smbAddress : list) {
                if (!provinceNames.contains(smbAddress.getProvince())) {
                    provinces.add(smbAddress);
                    provinceNames.add(smbAddress.getProvince());
                }
                if (!cityNames.contains(smbAddress.getProvince() + "_" + smbAddress.getCity())) {
                    cities.add(smbAddress);
                    cityNames.add(smbAddress.getProvince() + "_" + smbAddress.getCity());
                }
                if (!countyNames.contains(smbAddress.getProvince() + "_" + smbAddress.getCity()+"_"+smbAddress.getDistrict())) {
                    counties.add(smbAddress);
                    countyNames.add(smbAddress.getProvince() + "_" + smbAddress.getCity()+"_"+smbAddress.getDistrict());
                }
            }
            LOGGER.info("smb==initData===省集合大小："+provinces.size()+"==市集合大小："+cities.size()+
                    "==县集合大小："+counties.size()+"==乡镇集合大小："+list.size());
            //构造一颗全国树，只包含省信息
            initGlobalTree(provinces);
            //每个省一个树，包含市，区县，乡镇信息
            initProvinceTreeNode(provinces, cities, counties, list);
        }
    }

    /**
     * 构造一颗全国树，只包含省信息
     * @param provinces
     */
    private void initGlobalTree(List<SmbAddress> provinces){
        TreeNode treeRoot = new TreeNode();
        treeRoot.setSelfName(SMB_ADDRESS_All_TREE_REDIS);
        treeRoot.setSelfCode(SMB_ADDRESS_All_TREE_REDIS);
        for(SmbAddress province : provinces){
            TreeNode treeProvince = new TreeNode();
            treeProvince.setSelfName(province.getProvince());
            treeProvince.setSelfCode(province.getProvinceId());
            treeProvince.setProvinceId(province.getProvinceId());
            treeRoot.addChildNode(treeProvince);
        }
        LOGGER.info("smb==initGlobalTree==初始化smb商城全国树");
        myRedisConn.hset(SMB_ADDRESS_All_TREE_REDIS, SMB_ADDRESS_All_TREE_REDIS, JsonUtil.toJson(treeRoot));
    }

    /**
     * 每个省一个树，包含市，区县，乡镇信息
     * @param provinces
     * @param cities
     * @param counties
     */
    private void initProvinceTreeNode(List<SmbAddress> provinces, List<SmbAddress> cities, List<SmbAddress> counties,List<SmbAddress> townships) {
        Map<String, TreeNode> map = new HashMap<String, TreeNode>(35);
        // 省份
        for (SmbAddress province : provinces) {
            TreeNode treeProvince = new TreeNode();
            treeProvince.setProvinceId(province.getProvinceId());
            treeProvince.setSelfName(province.getProvince());
            treeProvince.setSelfCode(province.getProvinceId());
            map.put(province.getProvince(), treeProvince);
        }
        // 市
        for (SmbAddress city : cities) {
            TreeNode treeProvince = map.get(city.getProvince());

            TreeNode treeCity = new TreeNode();
            treeCity.setSelfName(city.getCity());
            treeCity.setSelfCode(city.getCityNo());
            treeCity.setZip(city.getZip());
            treeProvince.addChildNode(treeCity);

            map.put(city.getProvince(), treeProvince);
        }
        // 县、区
        for (SmbAddress county : counties) {
            TreeNode treeProvince = map.get(county.getProvince());
            TreeNode treeCity = treeProvince.findTreeNodeById(county.getCity(),false,true);

            TreeNode treeCounty = new TreeNode();
            treeCounty.setSelfName(county.getDistrict());
            treeCounty.setSelfCode(county.getDistrictNo());
            treeCity.addChildNode(treeCounty);

            map.put(county.getProvince(), treeProvince);
        }
        //乡镇
        for (SmbAddress township : townships) {
            TreeNode treeProvince = map.get(township.getProvince());
            TreeNode treeCity = treeProvince.findTreeNodeById(township.getCity(), false, true);
            TreeNode treeCounty = treeCity.findTreeNodeById(township.getDistrict(),false,true);

            TreeNode treeTownship = new TreeNode();
            treeTownship.setSelfName(township.getCounty());
            treeTownship.setSelfCode(township.getCountyNo());
            treeTownship.setAddressId(township.getAddressId());
            treeCounty.addChildNode(treeTownship);

            map.put(township.getProvince(), treeProvince);
        }
        //每个省一个树，包含市，区县，乡镇信息
        for (Map.Entry<String, TreeNode> entry : map.entrySet()) {
            LOGGER.info("smb==initProvinceTreeNode==初始化smb商城省份树=="+entry.getKey());
            myRedisConn.hset(SMB_ADDRESS_PROVINCE_TREE_REDIS + entry.getKey(), SMB_ADDRESS_PROVINCE_TREE_REDIS + entry.getKey(), JsonUtil.toJson(entry.getValue()));
        }
    }

    //获取smb四级地址库所有数据
    private List<SmbAddress> getAllFourLevelSmbAddress(){
        Connection conn = null;
        try {
            Class.forName(driveClassName);
            conn = DriverManager.getConnection(url, username, password);
            String sql = "select * from smb_fourleveladdress";
            QueryRunner queryRunner = new QueryRunner();
            List<SmbAddress> list = queryRunner.query(conn, sql, new BeanListHandler<SmbAddress>(SmbAddress.class, new BasicRowProcessor(new BeanProcessor(getMap()))));
            return list;
        } catch (Exception e) {
            LOGGER.info("smb==reloadAreaAddress==获取smb四级地址库数据==出现异常=="+e.getMessage(),e);
        }finally {
            if (conn!=null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    //定义smb四级地址库列名和属性名的映射
    private Map<String,String> getMap(){
        Map<String,String> map = new HashMap<>();
        map.put("ID","id");
        map.put("ProvinceID","provinceId");
        map.put("Province","province");
        map.put("City", "city");
        map.put("District","district");
        map.put("County","county");
        map.put("Street","street");
        map.put("AddressID","addressId");
        map.put("Postal","zip");
        map.put("CreateTime","createTime");
        map.put("CreateBy","createBy");
        map.put("UpdateTime","updateTime");
        map.put("UpdateBy", "updateBy");
        return map;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDriveClassName() {
        return driveClassName;
    }

    public void setDriveClassName(String driveClassName) {
        this.driveClassName = driveClassName;
    }

}
