package com.lenovo.m2.hsbuy.job.order.service.impl;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.lenovo.m2.hsbuy.job.domain.order.Goodsmaterials;
import com.lenovo.m2.hsbuy.job.manager.order.smb.GoodsmaterialsManager;
import com.lenovo.m2.hsbuy.job.manager.order.smb.GoodsmaterialsSmbdbManager;
import com.lenovo.m2.hsbuy.job.order.service.SmbGoodsMaterialsApiService;
import com.lenovo.m2.hsbuy.job.redis.MyRedisConn;
import com.lenovo.m2.hsbuy.job.redis.Pair;
import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by zhaocl1 on 2016/8/17.
 */
@Service("smbGoodsMaterialsService")
public class SmbGoodsMaterialsServiceImpl implements SmbGoodsMaterialsApiService {

    private static final Logger log = Logger.getLogger(SmbGoodsMaterialsServiceImpl.class);
    @Autowired
    private GoodsmaterialsSmbdbManager goodsmaterialsSmbdbManager;
    @Autowired
    private GoodsmaterialsManager goodsmaterialsManager;
    @Resource(name="sentryRedisConn")
    private MyRedisConn redisConn;

    private static final String redisPre = "Order#smb#mtart#";
    private static final String key_just4del = "Order#smb#mtart#just4del";
    private static final String value_just4del = "just4del";
    private static final int NUM = 10000;

    @Override
    public void transferSmbGoodsMaterials() {
        List<Goodsmaterials> list = null;
        try {
            long starttime = System.currentTimeMillis();
            list = goodsmaterialsSmbdbManager.selectMtart();
            log.info("---------查询物料结束 花费时间：" + (System.currentTimeMillis() - starttime) + "ms 查询出来数据大小 size=" + (list == null ? 0 : list.size()));
        } catch(Exception e) {
            log.error("---------查询物料表时出现异常！");
            log.error(e.getMessage(), e);
            return;
        }

        if (CollectionUtils.isEmpty(list)) {
            return;
        }

        try {
            long starttime = System.currentTimeMillis();
            goodsmaterialsManager.saveSmbGoodsmaterials(list);
            log.info("---------插入物料结束 花费时间：" + (System.currentTimeMillis() - starttime) + "ms ");
        } catch(Exception e) {
            log.error("---------插入物料表时出现异常！");
            log.error(e.getMessage(), e);
            return;
        }

        try {
            long t1 = System.currentTimeMillis();
            redisConn.set(key_just4del, value_just4del);
            long del_sum = redisConn.delKeysLike(redisPre);
            log.info("---------删除缓存成功，花费时间：" + (System.currentTimeMillis() - t1) + "ms, 删除数据量 size=" + del_sum);
        } catch(Exception e) {
            log.error("---------删除缓存中物料信息时出现异常！");
            log.error(e.getMessage(), e);
            return;
        }
        long t2 = System.currentTimeMillis();

        List<Pair<String, String>> pairs = new ArrayList<Pair<String, String>>();
        List<List<Pair<String, String>>> pairsList = new ArrayList<List<Pair<String, String>>>();
        Pair pair = null;
        for(Goodsmaterials g : list) {
            pair = new Pair(redisPre + g.getLenovoMaterialNumber() + "#" + g.getProductGroupNo(), (StringUtils.isEmpty(g.getMtart()) ? "" : g.getMtart()));
            pairs.add(pair);
        }

        for(int i = 0; i < pairs.size(); i += NUM) {
            List<Pair<String, String>> pairs_son = pairs.subList(i, getMinNum(i + NUM, pairs.size()));
            pairsList.add(pairs_son);
        }
        int size = 0;
        for(List<Pair<String, String>> pairs_tosave : pairsList) {
            List<Object> returnList = redisConn.batchSetString(pairs_tosave);
            size = size + (returnList != null ? returnList.size() : 0);
        }

        log.info("---------物料放入缓存结果大小size=" + size + ", 花费时间：" + (System.currentTimeMillis() - t2) + "ms");

    }

    private int getMinNum(int num1, int num2) {
        if (num1 > num2) {
            return num2;
        } else {
            return num1;
        }
    }


    @Override
    public void transferSmbGoodsMaterialsByCreateTime() {
        List<Goodsmaterials> list = null;
        try {
            long starttime = System.currentTimeMillis();
            String creatTime = this.getCreateTime();
            log.info("<========转移增量物料得时间条件：" + creatTime + "==========>");
            if (org.apache.commons.lang.StringUtils.isEmpty(creatTime)) {
                return;
            }
            list = goodsmaterialsSmbdbManager.selectMtartByCreateTime(creatTime);
            log.info("---------转移增量数据 查询物料结束 花费时间：" + (System.currentTimeMillis() - starttime) + "ms 查询出来数据大小 size=" + (list == null ? 0 : list.size()));
        } catch(Exception e) {
            log.error("---------转移增量数据 查询物料表时出现异常！");
            log.error(e.getMessage(), e);
            return;
        }

        if (CollectionUtils.isEmpty(list)) {
            return;
        }

        try {
            long starttime = System.currentTimeMillis();
            int size = goodsmaterialsManager.saveSmbGoodsmaterialsByCreateTime(list);
            log.info("---------插入物料结束 花费时间：" + (System.currentTimeMillis() - starttime) + "ms 存入数据大小size=" + size);
        } catch(Exception e) {
            log.error("---------插入物料表时出现异常！");
            log.error(e.getMessage(), e);
            return;
        }


        long t2 = System.currentTimeMillis();
        int size = 0;
        for(Goodsmaterials g : list) {
            String key = redisPre + g.getLenovoMaterialNumber() + "#" + g.getProductGroupNo();
            String value = redisConn.get(key);
            if (StringUtils.isNotEmpty(value)) {
                log.info("----物料已存在----物料类型id=" + g.getId() + "----key=" + key + ",value=" + (StringUtils.isEmpty(g.getMtart()) ? "" : g.getMtart()) + "----");
                continue;
            }
            redisConn.set(key, (StringUtils.isEmpty(g.getMtart()) ? "" : g.getMtart()));
            log.info("----物料类型id=" + g.getId() + "----key=" + key + ",value=" + (StringUtils.isEmpty(g.getMtart()) ? "" : g.getMtart()) + "存入缓存" );
            size++;
        }

        log.info("---------物料放入缓存结果大小size=" + size + ", 花费时间：" + (System.currentTimeMillis() - t2) + "ms");
    }

    private String getCreateTime() {
        Date now = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String year = sdf.format(getbeforeDay(now));
        return year + " 08:00:00";
    }

    /**
     * 获取前五天（避免物料同步不到）
     * @param date
     * @return
     */
    private static Date getbeforeDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, -5);//-1 今天的时间减五天
        date = calendar.getTime();
        return date;
    }
}
