package com.lenovo.m2.hsbuy.job.order.workers;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.hsbuy.job.order.service.ScanOrderApiService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;


/**
 * <pre>
 *    author  : licy13
 *    email   : licy13@lenovo.com
 *    time    : 2017/9/29 14:44
 *    desc    : 扫单job
 *    version : v1.0
 * </pre>
 */
public class ScanOrderJob {

    private final static Logger LOGGER = LogManager.getLogger();

    @Autowired
    private ScanOrderApiService scanOrderApiService;

    @Value("${dynamic.env}")
    private String leconfEnv;


    public void scanHsOrder() {
        LOGGER.info("---------惠商扫单 start ---------");
        try {

            //获取待扫单列表
            RemoteResult<List<Long>> result = scanOrderApiService.queryHsScanOrderIds(leconfEnv);
            if (!result.isSuccess()) {
                LOGGER.error("scanHsOrder error={}", result.getResultMsg());
                return;
            }

            List<Long> orderIds = result.getT();
            LOGGER.info("scanHsOrder env={} 获取待扫单列表 size={}", leconfEnv, orderIds == null ? 0 : orderIds.size());

            //待扫单列表为空，直接返回
            if (CollectionUtils.isEmpty(orderIds)) {
                return;
            }

            ExecutorService executorService = Executors.newFixedThreadPool(3);

            try {
                for(final Long orderId : orderIds) {
                    executorService.execute(new Runnable() {
                        public void run() {
                            scanOrderApiService.scanOrderByOrderId(orderId);
                        }
                    });
                }
            } catch(Exception e) {
                LOGGER.error("scanOrderByOrderId error", e);
            } finally {
                executorService.shutdown();
            }

            // awaitTermination返回false即超时会继续循环，返回true即线程池中的线程执行完成主线程跳出循环往下执行，每隔10秒循环一次
            while(!executorService.awaitTermination(10, TimeUnit.SECONDS)) {
            }

            LOGGER.info(" scanHsOrder 扫单执行完成，执行订单 size={} ", orderIds.size());

        } catch(Exception e) {
            LOGGER.error("scanHsOrder error", e);
        }
    }
}
