package com.lenovo.m2.hsbuy.job.promotion.service.impl;

import com.lenovo.m2.hsbuy.job.manager.promotion.PromotionIsUseJobManager;
import com.lenovo.m2.hsbuy.job.promotion.service.PromotionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by luqian on 2015-12-05.
 */
@Service
public class PromotionServiceImpl implements PromotionService {
    private static final Logger logger = LoggerFactory.getLogger(PromotionServiceImpl.class);

    @Autowired
    private PromotionIsUseJobManager promotionIsUseJobManager;

    @Override
    public void updatePromotionIsUse() {
        try {
            promotionIsUseJobManager.updatePromotionIsUse();  //更新促销表启用状态是未启用的数据 Disabled = 0
        } catch (Exception e) {
            logger.error("更新促销规则启用状态失效异常-->", e);
        }

    }

}
