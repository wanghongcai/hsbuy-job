package com.lenovo.m2.hsbuy.job.address.work;

import com.jayway.jsonpath.JsonPath;
import com.lenovo.m2.hsbuy.job.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.job.common.util.StringUtil;
import com.lenovo.m2.hsbuy.job.dao.address.HSAddressMapper;
import com.lenovo.m2.hsbuy.job.domain.address.HsAddress;
import com.lenovo.m2.hsbuy.job.domain.address.TreeNode;
import com.lenovo.m2.hsbuy.job.redis.MyRedisConn;
import com.lenovo.open.gateway.java.sdk.JavaSDKClient;
import com.lenovo.open.gateway.java.sdk.util.Response;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

/**
 * Created by admin on 2017/11/27.
 */
public class HSSyncAreaAddressWorker {
    private static final Logger LOGGER = LoggerFactory.getLogger(HSSyncAreaAddressWorker.class);

    private String openapiUrl;
    private String openapiAppKey;
    private String openapiSecret;
    private static final String HS_ADDRESS_TREE_REDIS = "hs_address_tree_redis";

    @Autowired
    private HSAddressMapper hsAddressMapper;
    @Autowired
    private MyRedisConn myRedisConn;

    public void execute(){
        try {
            reloadAreaAddress();
            LOGGER.info("SMBSyncAreaAddressWorker==执行成功");
        }catch (Exception e){
            LOGGER.info("SMBSyncAreaAddressWorker==出现异常=="+e.getMessage(),e);
        }
    }

    /**
     * 从开放平台获取最新的省市区县信息，更新自己的数据库
     */
    private void reloadAreaAddress() {
        //获取惠商商城最新的省市区县地址信息
        List<HsAddress> list = getAllHuiShangAreaAddress();
        if(null != list && list.size() >0){
            LOGGER.info("HS==reloadAreaAddress==获取到的HS三级地址条数=="+list.size());
            int t = hsAddressMapper.deleteThreeLevelHSAddress();
            LOGGER.info("HS==reloadAreaAddress==删除的HS三级地址条数=="+t);
            //查询成功，并且删除成功，将最新的数据插入到数据库中
            if(t >= 0){
                //分批保存
                int mod = list.size()%100 == 0 ? list.size()/100:list.size()/100+1;
                int temp=0;
                for(int i=0;i<mod;i++){
                    if(i == mod-1){
                        List<HsAddress> sub = list.subList(i*100, list.size());
                        temp += hsAddressMapper.initBatchInsertThreeLevelAddress(sub);
                    }else{
                        List<HsAddress> sub = list.subList(i*100, i*100+100);
                        temp += hsAddressMapper.initBatchInsertThreeLevelAddress(sub);
                    }
                }
                LOGGER.info("HS==reloadAreaAddress==新插入的HS三级地址条数=="+temp);
                //新数据插入成功才进行初始化
                if(temp >0){
                    initData();
                }
            }
        }
    }

    /**
     * 调用开放平台，获取惠商商城最新的省市区县地址信息
     * @return
     */
    private List<HsAddress> getAllHuiShangAreaAddress() {
        String method = "lenovo.integrate.GetChinaAddress.com_hs";
        int total = 1;
        Map<String, Object> map = new HashMap<String, Object>();
        //惠商省市区县最新地址信息
        List<HsAddress> mylist = new ArrayList<>(10000);
        //防止重复
        Set<String> sets = new HashSet<>(10000);
        //分页获取数据，如果有一页数据无法获取则，停止执行
        boolean occurError = false;
        for(int i=0;i<total;i++){
            map.put("pageindex", i+1);
            String result = getOpenApiResult(openapiUrl, openapiAppKey, openapiSecret, method, map, null);
            if(StringUtil.isEmpty(result)){
                occurError = true;
                break;
            }
            List<Object> list = JsonPath.read(result, "$.page.data");
            HsAddress entity = null;
            List<Object> cityList = new ArrayList<>(1000);
            List<Object> districtList = new ArrayList<>(5000);
            for(Object o : list){
                cityList = JsonPath.read(o, "$.citys");
                for(Object c : cityList){
                    districtList = JsonPath.read(c, "$.districts");
                    for (Object d : districtList){
                        LinkedHashMap<String,String> j = (LinkedHashMap<String,String>) o;
                        LinkedHashMap<String,String> k = (LinkedHashMap<String,String>) c;
                        LinkedHashMap<String,String> l = (LinkedHashMap<String,String>) d;
                        String key = j.get("provinceCode")+"|"+j.get("provinceName")+"|"+k.get("cityno")+"|"+k.get("cityname")+"|"+l.get("countyno")+"|"+l.get("countryname");
                        if(sets.contains(key)){
                            continue;
                        }
                        sets.add(key);
                        entity = new HsAddress();
                        entity.setProviceNo(j.get("provinceCode"));
                        entity.setProviceName(j.get("provinceName"));
                        entity.setCityNo(k.get("cityno"));
                        entity.setCityName(k.get("cityname"));
                        entity.setDistricNo(l.get("countyno"));
                        entity.setDistricName(l.get("countryname"));
                        mylist.add(entity);
                    }
                }
            }
        }
        if(!occurError){
            return mylist;
        }
        return null;
    }

    /**
     * 调用开放平台，获取最新的惠商三级地址信息
     * @param openapiUrl
     * @param openapiAppKey
     * @param openapiScrebt
     * @param method
     * @param paraMap
     * @param sysMap
     * @return
     */
    private String getOpenApiResult(String openapiUrl,String openapiAppKey, String openapiScrebt, String method, Map<String,Object> paraMap,  Map<String,Object> sysMap) {
        try {
            Response response = JavaSDKClient.proxy(openapiUrl, openapiAppKey, openapiScrebt, method, paraMap, sysMap);
            LOGGER.info("getOpenApiResult==开放平台返回值=="+ JsonUtil.toJson(response));
            Map temp = JsonUtil.fromJson(response.getBody().toString(), Map.class);
            Object success = temp.get("success");
            if ("true".equals(String.valueOf(success))) {
                Map obj = (Map) temp.get("result");
                Object res = obj.get(String.format("%s_response", method.replaceAll("\\.", "_")));
                LOGGER.info("getOpenApiResult==返回值=="+res);
                return JsonUtil.toJson(res);
            } else {
                LOGGER.error("getOpenApiResult==调用开放平台失败，方法=="+method);
                return null;
            }
        } catch (Exception e) {
            LOGGER.error("getOpenApiResult==调用开放平台失败，方法=="+method);
            return null;
        }
    }

    /**
     * 初始化redis中数据
     */
    private void initData() {
        LOGGER.info("hs==执行了initData！");
        List<HsAddress> list = hsAddressMapper.getAll();
        if (CollectionUtils.isNotEmpty(list)) {
            //存储所有省信息
            List<HsAddress> provinces = new ArrayList<>(35);
            //存储所有省名称
            Set<String> provinceNames = new HashSet<>();
            //存储所有市信息
            List<HsAddress> cities = new ArrayList<>();
            //存储所有市名称
            Set<String> cityNames = new HashSet<>();
            //list中的数据就是所有区县
            for (HsAddress hsAddress : list) {
                if (!provinceNames.contains(hsAddress.getProviceName())) {
                    provinces.add(hsAddress);
                    provinceNames.add(hsAddress.getProviceName());
                }
                if (!cityNames.contains(hsAddress.getProviceName() + "_" + hsAddress.getCityName())) {
                    cities.add(hsAddress);
                    cityNames.add(hsAddress.getProviceName() + "_" + hsAddress.getCityName());
                }
            }
            /*LOGGER.info("hs==initData===省集合大小："+provinces.size()+"==省集合内容："+JsonUtil.toJson(provinces)
                                +"==市集合大小："+cities.size()+"==市集合内容："+JsonUtil.toJson(cities)
                                +"==县集合大小："+list.size()+"==县集合内容："+JsonUtil.toJson(list));*/
            LOGGER.info("hs==initData===省集合大小："+provinces.size()+"==市集合大小："+cities.size()+"==县集合大小："+list.size());
            initTreeNode(provinces, cities, list);
        }
    }

    /**
     * 构造一颗惠商地址树
     * @param provinces
     * @param cities
     * @param counties
     */
    private void initTreeNode(List<HsAddress> provinces, List<HsAddress> cities, List<HsAddress> counties) {
        Map<String, TreeNode> map = new HashMap<String, TreeNode>(35);
        TreeNode treeRoot = new TreeNode();
        treeRoot.setSelfName(HS_ADDRESS_TREE_REDIS);
        treeRoot.setSelfCode(HS_ADDRESS_TREE_REDIS);
        // 省份
        for (HsAddress province : provinces) {
            TreeNode treeProvince = new TreeNode();
            treeProvince.setProvinceId(province.getProviceNo());
            treeProvince.setSelfName(province.getProviceName());
            treeProvince.setSelfCode(province.getProviceNo());
            map.put(province.getProviceName(), treeProvince);
        }
        // 市
        for (HsAddress city : cities) {
            TreeNode treeProvince = map.get(city.getProviceName());
            TreeNode treeCity = new TreeNode();
            treeCity.setSelfName(city.getCityName());
            treeCity.setSelfCode(city.getCityNo());
            treeProvince.addChildNode(treeCity);
            map.put(city.getProviceName(), treeProvince);
        }
        // 县、区
        for (HsAddress county : counties) {
            TreeNode treeProvince = map.get(county.getProviceName());
            TreeNode cityNode = treeProvince.findTreeNodeById(county.getCityName(),false,true);

            TreeNode treeCounty = new TreeNode();
            treeCounty.setSelfName(county.getDistricName());
            treeCounty.setSelfCode(county.getDistricNo());
            cityNode.addChildNode(treeCounty);

            map.put(county.getProviceName(), treeProvince);
        }
        for (Map.Entry<String, TreeNode> entry : map.entrySet()) {
            TreeNode node = entry.getValue();
            treeRoot.addChildNode(node);
        }
        LOGGER.info("hs==initTreeNode==初始化惠商商城地址库");
        myRedisConn.hset(HS_ADDRESS_TREE_REDIS, HS_ADDRESS_TREE_REDIS, JsonUtil.toJson(treeRoot));
    }

    public String getOpenapiUrl() {
        return openapiUrl;
    }

    public void setOpenapiUrl(String openapiUrl) {
        this.openapiUrl = openapiUrl;
    }

    public String getOpenapiAppKey() {
        return openapiAppKey;
    }

    public void setOpenapiAppKey(String openapiAppKey) {
        this.openapiAppKey = openapiAppKey;
    }

    public String getOpenapiSecret() {
        return openapiSecret;
    }

    public void setOpenapiSecret(String openapiSecret) {
        this.openapiSecret = openapiSecret;
    }
}
