package com.lenovo.m2.hsbuy.job.inventory.service.impl;


import com.lenovo.m2.hsbuy.domain.inventory.StockInfo;
import com.lenovo.m2.hsbuy.job.inventory.service.StockService;
import com.lenovo.m2.hsbuy.job.manager.inventory.StockManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by bob on 2015/7/3.
 */
@Service("stockService")
public class StockServiceImpl implements StockService {
    private static final Logger LOGGER = LoggerFactory.getLogger(StockServiceImpl.class);
    @Autowired
    private StockManager stockManager;


    @Override
    public List<StockInfo> getHsOnlineStock() {
        return stockManager.getHsOnlineStock();
    }
}
