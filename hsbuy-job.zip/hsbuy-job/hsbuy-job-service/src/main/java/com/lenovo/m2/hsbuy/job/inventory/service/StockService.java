package com.lenovo.m2.hsbuy.job.inventory.service;

import com.lenovo.m2.hsbuy.domain.inventory.StockInfo;

import java.util.List;

/**
 * Created by bob on 2015/7/3.
 */
public interface StockService {

    /**
     * 获取上架状态的惠商在线库存列表
     * @return
     */
    List<StockInfo> getHsOnlineStock();

}

