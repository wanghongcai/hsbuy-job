package com.lenovo.m2.hsbuy.job.common.order.enums;

/**
 * 返回信息
 *
 * @Author licy13
 * @Date 2017/4/11
 */

public enum ResultMessageEnum {


    SUCCESS("1000", "操作成功"),
    ERROR_PARAM("1001", "参数有误"),
    ERROR_EMPTY_ORDER("1002", "未查到订单信息"),
    ERROR_PAID_CALLBACK_SLOW("1003", "支付回调晚，订单已经扫单完成，需补资源"),
    PAUSE_SCAN_ORDER("1004", "中止扫单"),
    ERROR_PAID_CALLBACK_SLOW_FAIL("1005", "支付回调晚，订单已经扫单，但扫单未成功，需定位失败原因"),


    ERROR("9999", "异常"),;


    private String code;
    private String desc;

    ResultMessageEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

}
