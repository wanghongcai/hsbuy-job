package com.lenovo.m2.hsbuy.job.common.order.enums;

import com.lenovo.m2.arch.framework.domain.Tenant;

import java.util.HashSet;

/**
 * @Author licy13
 * @Date 2017/5/17
 */

public enum ShopIdsEnum {
    LENOVO(1, "lenovo"),
    THINK(2, "think"),
    EPP(3, "epp"),
    ROMING(4, "roming"),
    MOTO(5, "moto"),
    DONGDE(6, "dongde"),
    THINKCENTER(7, "thinkcenter"),
    SMB(8, "17 商城"),
    SMB_SCORE(9, "17积分商城"),
    PCSD(11, "PCSD商城"),
    HUISHANG(14, "慧商商城"),
    HUISHANG_SCORE(15, "慧商积分商城"),
    MOTO_INDIA(16, "moto印度商城"),;

    private final int type;
    private final String desc;

    ShopIdsEnum(int type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    public int getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }

    public static final HashSet<Integer> shopIdSet = new HashSet();

    static {
        for(ShopIdsEnum shopIdsEnum : ShopIdsEnum.values()) {
            shopIdSet.add(shopIdsEnum.getType());
        }
    }

    /**
     * 判断是否合法商户
     *
     * @param tenant
     * @return
     */
    public static Boolean isIlllegalShopId(Tenant tenant) {
        return !isLegalShopId(tenant);
    }

    public static Boolean isLegalShopId(Tenant tenant) {
        if (tenant == null || tenant.getShopId() <= 0) {
            return false;
        }
        return isLegalShopId(tenant.getShopId());
    }

    public static Boolean isLegalShopId(int shopId) {
        if (shopId <= 0) {
            return false;
        }
        return shopIdSet.contains(shopId);
    }

    /**
     * 判断是否惠商
     *
     * @param tenant
     * @return
     */
    public static Boolean isHuiShang(Tenant tenant) {
        if (tenant == null || tenant.getShopId() <= 0) {
            return false;
        }
        return isHuiShang(tenant.getShopId());
    }

    public static Boolean isHuiShang(int shopId) {
        if (shopId <= 0) {
            return false;
        }
        return shopId == HUISHANG.getType();
    }

    /**
     * 判断是否SMB商城
     *
     * @param tenant
     * @return
     */
    public static Boolean isSMB(Tenant tenant) {
        if (tenant == null || tenant.getShopId() <= 0) {
            return false;
        }
        return isSMB(tenant.getShopId());
    }

    public static Boolean isSMB(int shopId) {
        if (shopId <= 0) {
            return false;
        }
        return shopId == SMB.getType();
    }


    public static void main(String[] args) {
        System.out.println(isLegalShopId(141));
    }

}