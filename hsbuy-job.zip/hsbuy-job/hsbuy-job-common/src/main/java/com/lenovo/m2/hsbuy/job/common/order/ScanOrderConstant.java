package com.lenovo.m2.hsbuy.job.common.order;


/**
 * 扫单常量
 * licy13 on 2017/9/28
 */
public class ScanOrderConstant {

    /**
     * 待扫单
     * init 0
     * 2-->0 取消订单失败
     * 4-->0 异常 转状态 4-->5
     */
    public static final int SCAN_STAUTS_WAITING = 0;
    /**
     * 扫单成功
     * 2-->1 扫单成功
     * 4-->1 异常 转状态 4-->5
     */
    public static final int SCAN_STAUTS_SUCCESS = 1;
    /**
     * 正在取消订单中
     * 0-->2 扫单中间状态
     * 4-->2 不处理，终止其他逻辑
     */
    public static final int SCAN_STAUTS_PENDING = 2;
    /**
     * 扫单暂停（支付系统不允许扫单 或 取消订单返回已支付）
     * 0-->3 支付系统回应不能扫单
     * 2-->3 中间件取消订单回应已经支付
     * 4-->3 不处理--已支付回调
     */
    public static final int SCAN_STAUTS_PAUSE = 3;
    /**
     * 已支付（支付回调通知已支付，不需要扫单）
     * 0-->4  支付回调
     * 1-->4  支付回调晚，已扫单成功--异常 转状态 1-->5
     * 2-->4  扫单中支付回调
     * 3-->4  已扫单中止
     */
    public static final int SCAN_STAUTS_PAID = 4;
    /**
     * 需要报警邮件或是短信
     * <p>
     * 支付回调晚异常 （已正常扫完单 或 已支付取消订单异常）
     * 4-->5
     * 1-->5
     */
    public static final int SCAN_STAUTS_ERROR = 5;


    /**
     * 订单状态--取消状态
     */
    public static final int ORDER_STATUS_CANCEL = 2;

    /**
     * 支付状态--已支付
     */
    public static final int PAY_STATUS_PAID = 1;

    /**
     * 取消订单类--扫单
     */
    public static final int CANCEL_TYPE_SCAN_ORDER = 4;



    /**
     * 订单已支付
     */
    public final static String ORDER_PAID= "1204";


    /**
     * @Param ORDER_PAYMENT_OFFLINE_TYPE 线下付款
     */
    public static final int ORDER_PAYMENT_OFFLINE_TYPE = 2;
}
