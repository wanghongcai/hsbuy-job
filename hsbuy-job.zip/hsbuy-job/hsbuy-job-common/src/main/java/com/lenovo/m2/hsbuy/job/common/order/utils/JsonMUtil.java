package com.lenovo.m2.hsbuy.job.common.order.utils;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.hsbuy.job.common.order.enums.MoneyTypeEnum;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.Version;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.codehaus.jackson.map.module.SimpleModule;
import org.codehaus.jackson.type.JavaType;
import org.codehaus.jackson.type.TypeReference;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @Author licy13
 * @Date 2017/6/2
 */

public class JsonMUtil {

    private static Logger LOGGER = LogManager.getLogger();


    public static final ObjectMapper OM = new ObjectMapper();

    static {
        // 设置输入时忽略在JSON字符串中存在但Java对象实际没有的属性
        OM.disable(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES);
        OM.configure(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);
        OM.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
        /*---money---*/
        SimpleModule module = new SimpleModule("money", Version.unknownVersion());
        module.addSerializer(Money.class, new MoneySerializer(MoneyTypeEnum.MONEY));
        module.addDeserializer(Money.class, new MoneyDeserializer());

        OM.registerModule(module);

//        OM.setSerializationInclusion(JsonSerialize.Inclusion.NON_NULL);
    }

    public static ObjectMapper moneyScore() {
        SimpleModule module = new SimpleModule("money", Version.unknownVersion());
        module.addSerializer(Money.class, new MoneySerializer(MoneyTypeEnum.SCORE));
        OM.registerModule(module);
        return OM;
    }

    public static JavaType assignList(Class<? extends Collection> collection, Class<? extends Object> object) {
        return JsonMUtil.OM.getTypeFactory().constructParametricType(collection, object);
    }


    public static <T> ArrayList<T> readValuesAsArrayList(String key, Class<T> object) {
        ArrayList<T> list = null;
        try {
            list = OM.readValue(key, assignList(ArrayList.class, object));
        } catch(Exception e) {
            LOGGER.error("JsonMUtil readValuesAsArrayList  error", e);
        }
        return list;
    }


    public static String toJson(Object obj) {
        if (obj == null) {
            return "";
        }
        try {
            return OM.writeValueAsString(obj);
        } catch(Exception e) {
            LOGGER.error("JsonMUtil toJson  error", e);
        }
        return null;
    }

    /**
     * @param sdf
     * @param json
     * @param clazz
     * @return
     * @Description: 重载个性化时间
     * @author yuzj7@lenovo.com
     * @date 2015年8月9日 下午4:19:18
     */
    public static <T> T fromJson(SimpleDateFormat sdf, String json, Class<T> clazz) {
        if (StringUtils.isEmpty(json)) {
            return null;
        }
        try {
            OM.setDateFormat(sdf);
            T t = OM.readValue(json, clazz);
            OM.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
            return t;
        } catch(Exception e) {
            LOGGER.error("JsonMUtil fromJson  error", e);
        }
        return null;
    }

    public static <T> T fromJson(String json, Class<T> clazz) {
        if (StringUtils.isEmpty(json)) {
            return null;
        }
        try {
            return OM.readValue(json, clazz);
        } catch(Exception e) {
            LOGGER.error("JsonMUtil fromJson  error", e);
        }
        return null;
    }

    public static <T> T fromJson(String json, TypeReference<T> typeReference) {
        if (StringUtils.isEmpty(json)) {
            return null;
        }
        try {
            return OM.readValue(json, typeReference);
        } catch(Exception e) {
            LOGGER.error("JsonMUtil fromJson  error", e);
        }
        return null;
    }


    public static String toJson(Object obj, String callback) {
        if (obj instanceof String) {
            return (String) obj;
        }
        String rs = null;
        try {
            JsonMUtil.OM.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
            rs = JsonMUtil.OM.writeValueAsString(obj);
        } catch(Exception e) {
            LOGGER.error("JsonMUtil toJson  error", e);
        }
        if (rs == null) {
            rs = "{\"rc\":-1}";//解析JSON异常/IO异常
        }
        if (StringUtils.isNotEmpty(callback)) {
            rs = String.format("%s(%s)", callback, rs);
        }
        return rs;
    }

    /**
     * 格式化json
     *
     * @param content
     * @return
     */
    public static String formatJson(String content) {

        StringBuffer sb = new StringBuffer();
        int index = 0;
        int count = 0;
        while(index < content.length()) {
            char ch = content.charAt(index);
            if (ch == '{' || ch == '[') {
                sb.append(ch);
                sb.append('\n');
                count++;
                for(int i = 0; i < count; i++) {
                    sb.append('\t');
                }
            } else if (ch == '}' || ch == ']') {
                sb.append('\n');
                count--;
                for(int i = 0; i < count; i++) {
                    sb.append('\t');
                }
                sb.append(ch);
            } else if (ch == ',') {
                sb.append(ch);
                sb.append('\n');
                for(int i = 0; i < count; i++) {
                    sb.append('\t');
                }
            } else {
                sb.append(ch);
            }
            index++;
        }
        return sb.toString();
    }

    /**
     * 把格式化的json紧凑
     *
     * @param content
     * @return
     */
    public static String compactJson(String content) {
        String regEx = "[\t\n]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(content);
        return m.replaceAll("").trim();
    }

    public static void main(String[] args) {
        String str = "{\"chargeAcct\":\"18766143231\",\"chargeCash\":\"充值500M\",\"chargeType\":1,\"flowPackageType\":0,\"flowPackageSize\":\"充值500M\",\"ispName\":\"移动\",\"belong\":\"山东移动\"}";
        Map map = JsonMUtil.fromJson(str, Map.class);
        String chargeAcct = (String) map.get("chargeAcct");
        String chargeType = String.valueOf(map.get("chargeType"));
//        System.out.println(chargeType);

        System.out.println(formatJson(str));
        System.out.println(compactJson(formatJson(str)));
    }

}
