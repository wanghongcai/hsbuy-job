package com.lenovo.m2.hsbuy.job.common.util;

import com.lenovo.m2.arch.framework.domain.Money;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.Version;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.module.SimpleModule;
import org.codehaus.jackson.type.JavaType;

import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * Created by fenglg1 on 2015/5/19.
 */
public class JsonUtil {
    private static Logger logger = Logger.getLogger(JsonUtil.class);

    public static ObjectMapper mapper = new ObjectMapper();


    static {
        mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        mapper.setSerializationInclusion(JsonSerialize.Inclusion.NON_NULL);

        // 设置输入时忽略在JSON字符串中存在但Java对象实际没有的属性
        mapper.disable(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.configure(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);
        mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
        /*---money---*/
        SimpleModule module = new SimpleModule("money", Version.unknownVersion());
        module.addSerializer(Money.class, new MoneyJsonSerializer());
        module.addSerializer(Date.class, new DateJsonSerializer());
        module.addDeserializer(Money.class, new MoneyJsonDeserializer());

        mapper.registerModule(module);
}

    public static String toJson(Object obj) {
        StringWriter writer = new StringWriter();
        JsonGenerator gen;
        try {
            return mapper.writeValueAsString(obj);
        } catch (IOException e) {
            logger.warn(e.getCause());
        }

        return null;
    }

    public static <T> T fromJson(String json, Class<T> classOfT) {
        Object object;
        try {
            object = mapper.readValue(json, classOfT);
            return (T) object;
        } catch (JsonParseException e) {
            logger.warn(e.getCause());
        } catch (JsonMappingException e) {
            logger.warn(e.getCause());
        } catch (IOException e) {
            logger.warn(e.getCause());
        }
        return null;
    }




    /**
     * json字符串转对象列表
     *
     * @param json 字符串
     * @param type List<Bean>中Bean的类型
     * @return
     */
    public static <T> List<T> toList(String json, Class<T> type) {
        if (json == null) {
            return null;
        }
        try {
            return mapper.readValue(json, assignList(List.class, type));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static JavaType assignList(Class<? extends Collection> collection, Class<? extends Object> object) {
        return mapper.getTypeFactory().constructParametricType(collection, object);
    }

    public static String toJson(Object obj, String callback) {
        if (obj instanceof String) {
            return (String) obj;
        }
        String rs = null;
        try {
            JsonUtil.mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
            rs = JsonUtil.mapper.writeValueAsString(obj);
        } catch(Exception e) {
            logger.error("toJson error -->", e);
        }
        if (rs == null) {
            rs = "{\"rc\":-1}";//解析JSON异常/IO异常
        }
        if (StringUtils.isNotEmpty(callback)) {
            rs = String.format("%s(%s)", callback, rs);
        }
        return rs;
    }

}
