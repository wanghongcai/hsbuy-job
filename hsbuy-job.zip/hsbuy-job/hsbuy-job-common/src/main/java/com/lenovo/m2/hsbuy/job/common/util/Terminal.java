package com.lenovo.m2.hsbuy.job.common.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by luqian on 2016-03-04.
 */
public class Terminal {

    private static final Map<Integer, Integer> map = new LinkedHashMap<Integer, Integer>();
    static {
        map.put(1,8);   //pc
        map.put(2,4);   //wap
        map.put(3,2);   //app
        map.put(4,1);   //weixin
    }
    public static Integer getTerminalD(Integer terminal){
        return map.get(terminal);
    }


    public static Boolean isExist(Integer redisTerminalD,Integer terminal){
        Integer terminalD =  getTerminalD(terminal);
        if(terminalD !=null){
             int result = redisTerminalD & terminalD;
            if(result != 0){
                return true;
            }else {
                return false;
            }
        }
        return false;
    }


    /**
     * 得到十进制的 终端数值
     * @return
     */
    public static Integer calcAccuTerminal(Integer[] terminals){
        if(terminals.length != 4){
            throw new IllegalArgumentException("terminals 参数错误" + Arrays.toString(terminals));
        }

        int accuTerminal = 0;

        for(int i=0; i < terminals.length; i++){
            if(terminals[i] == 1){
                accuTerminal += map.get(i + 1);
            }
        }
        return accuTerminal;
    }




    
    public static void main(String[] args) {
		
    	System.out.println(isExist(1, 1));
    	
	}



}
