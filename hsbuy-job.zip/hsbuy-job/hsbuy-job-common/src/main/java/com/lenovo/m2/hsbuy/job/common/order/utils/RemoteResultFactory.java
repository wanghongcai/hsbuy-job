package com.lenovo.m2.hsbuy.job.common.order.utils;


import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.job.common.order.enums.ResultMessageEnum;
import com.lenovo.m2.hsbuy.job.common.order.exception.BusinessException;
import org.apache.commons.lang.StringUtils;

import java.util.Date;

/**
 * @author wangrq1
 * @create 2017-03-17 下午4:00
 **/
public class RemoteResultFactory {

    private RemoteResultFactory(){};


    public static RemoteResult getErrorResult(ResultMessageEnum messageEnum, String reason){
        RemoteResult ret = new RemoteResult(false);
        ret.setCreateTime(new Date());
        ret.setResultCode(messageEnum.getCode());
        if(StringUtils.isEmpty(reason)){
           ret.setResultMsg(messageEnum.getDesc());
        }else{
            ret.setResultMsg(reason);
        }
        return  ret;
    }


    public static RemoteResult getErrorResult(ResultMessageEnum messageEnum){
        return getErrorResult(messageEnum, null);
    }



    public static RemoteResult getErrorResult(BusinessException exception, String reason){
        RemoteResult ret = new RemoteResult(false);
        ret.setCreateTime(new Date());
        ret.setResultCode(exception.getErrno());
        if(StringUtils.isEmpty(reason)){
            ret.setResultMsg(exception.getMessage());
        }else{
            ret.setResultMsg(reason);
        }
        return  ret;
    }


    public static RemoteResult getErrorResult(BusinessException exception){
        return getErrorResult(exception, null);
    }

    public static <T> RemoteResult getSuccessResult(T t){
        RemoteResult ret = new RemoteResult(true);
        ret.setCreateTime(new Date());
        ret.setResultCode(ResultMessageEnum.SUCCESS.getCode());
        ret.setT(t);
        return ret;
    }


    public static RemoteResult getSuccessResult(){
        RemoteResult ret = new RemoteResult(true);
        ret.setCreateTime(new Date());
        ret.setResultCode(ResultMessageEnum.SUCCESS.getCode());
        return ret;
    }



}
