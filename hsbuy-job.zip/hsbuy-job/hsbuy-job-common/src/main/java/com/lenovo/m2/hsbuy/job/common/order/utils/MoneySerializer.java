package com.lenovo.m2.hsbuy.job.common.order.utils;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.hsbuy.job.common.order.enums.MoneyTypeEnum;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

import java.io.IOException;

public class MoneySerializer extends JsonSerializer<Money> {

    private MoneyTypeEnum type;


    public MoneyTypeEnum getType() {
        return type;
    }

    public void setType(MoneyTypeEnum type) {
        this.type = type;
    }

    private MoneySerializer() {

    }

    public MoneySerializer(MoneyTypeEnum type) {
        this.setType(type);
    }


    @Override
    public void serialize(Money value, JsonGenerator jgen, SerializerProvider provider)
            throws IOException, JsonProcessingException {
        if (value == null) {
            return;
        }

        switch(this.getType()) {
            case MONEY:
                jgen.writeStartObject();
                jgen.writeStringField("amount", value.getAmount().toString());
                jgen.writeStringField("currencyCode", value.getCurrencyCode());
                jgen.writeEndObject();
                break;
            case SCORE:
                jgen.writeString(String.valueOf(value.getAmount().intValue()));
                break;

            default:
                jgen.writeString(value.getAmount().toString());
                break;
        }
    }

}
