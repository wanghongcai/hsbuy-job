package com.lenovo.m2.hsbuy.job.common.util;


import com.lenovo.m2.arch.framework.domain.Money;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

import java.io.IOException;

/**
 * Created by zhangzhen on 17/3/20.
 */
public class MoneyJsonSerializer extends JsonSerializer<Money> {
    @Override
    public void serialize(Money value, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {
        gen.writeStartObject();
        gen.writeStringField("amount", value.getAmount().toString());
        gen.writeStringField("currencyCode", value.getCurrencyCode());
        gen.writeEndObject();
    }

}
