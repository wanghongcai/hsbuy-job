package com.lenovo.m2.hsbuy.job.common.util;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import org.apache.commons.lang3.StringUtils;

/**
 * @author wangrq1
 * @create 2017-03-17 下午4:00
 **/
public class RemoteResultFactory {

    private RemoteResultFactory(){};



    public static <T> RemoteResult getSuccessResult(T t){
        RemoteResult ret = new RemoteResult(true);
        ret.setResultCode("0");
        ret.setT(t);
        return ret;
    }


    public static RemoteResult getSuccessResult(){
        RemoteResult ret = new RemoteResult(true);
        ret.setResultCode("0");
        return ret;
    }



}
