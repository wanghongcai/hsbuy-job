package com.lenovo.m2.hsbuy.job.common;

/**
 * Cache Key汇总
 */
public class CacheConstant {
    /*================ 相关缓存常量=====================*/
    public static final String CACHE_PREFIX_INIT_MEMBERVATINVOICE = "INVOICE_MEMBERVATINVOICE_";
    public static final String CACHE_PREFIX_INIT_FAID = "INVOICE_MEMBERFAID_";

}
