package com.lenovo.m2.hsbuy.job.common.util;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.tool.util.StringUtils;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.JsonToken;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;

import java.io.IOException;
import java.util.Currency;

/**
 * Created by zhangzhen on 17/3/20.
 */
public class MoneyJsonDeserializer extends JsonDeserializer<Money> {

    private static String AMOUNT = "amount";
    private static String CURRENCY_CODE = "currencyCode";


    @Override
    public Money deserialize(JsonParser jp, DeserializationContext ctxt)
            throws IOException, JsonProcessingException {

        JsonToken jt = jp.getCurrentToken();

        if(jt == JsonToken.VALUE_STRING){
            String name = jp.getText();
            return  new Money(name,"CNY");
        }

        if(jt == JsonToken.VALUE_NUMBER_INT){
            Integer name = jp.getIntValue();
            return  new Money(String.valueOf(name),"CNY");
        }

        if(jt == JsonToken.VALUE_NUMBER_FLOAT){
            Float name = jp.getFloatValue();
            return  new Money(String.valueOf(name),"CNY");
        }


        if(jt != JsonToken.START_OBJECT){
            return null;
        }

        String amount = null;
        String currency = null;

        while(jt != JsonToken.END_OBJECT){
            if(jt  == JsonToken.START_OBJECT){
                jt = jp.nextToken();
            }else if(jt == JsonToken.FIELD_NAME){
                String name = jp.getText();
                jt = jp.nextToken();
                String value = jp.getText();
                if(AMOUNT.equals(name)){
                    amount = value;
                }else if(CURRENCY_CODE.equals(name)){
                    currency = value;
                }
                jt = jp.nextToken();
            }
        }
        if(amount == null || currency == null){
            return null;
        }
        return new Money(amount, Currency.getInstance(currency));

    }
}
