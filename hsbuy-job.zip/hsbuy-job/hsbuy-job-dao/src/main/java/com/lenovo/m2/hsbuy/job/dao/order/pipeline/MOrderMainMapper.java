package com.lenovo.m2.hsbuy.job.dao.order.pipeline;

import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderMain;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by fenglg1 on 2016/2/24.
 */
public interface MOrderMainMapper {

    /**
     * 根据订单号获取一拆订单信息
     *
     * @param orderId
     * @return
     */
    MOrderMain getOrderMainByOrderID(@Param("orderId") Long orderId);


    /**
     * 根据订单号获取一拆订单信息
     *
     * @param orderCode
     * @return
     */
    MOrderMain getOrderMainByOrderCode(@Param("orderCode") Long orderCode);

    //获取二拆异常订单
    List<MOrderMain> getExceptionMOrderMain();
}
