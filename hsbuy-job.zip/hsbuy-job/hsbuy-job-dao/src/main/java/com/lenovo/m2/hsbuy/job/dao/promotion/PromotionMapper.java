package com.lenovo.m2.hsbuy.job.dao.promotion;


public interface PromotionMapper {
    int  updatePromotionIsUse();
}
