package com.lenovo.m2.hsbuy.job.dao.order.pipeline;


import com.lenovo.m2.hsbuy.job.domain.order.ScanOrder;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;


/**
 * <pre>
 *    author  : licy13
 *    email   : licy13@lenovo.com
 *    time    : 2017/9/27 18:18
 *    desc    :  扫单表 DAO
 *    version : v1.0
 * </pre>
 */
public interface ScanOrderMapper {

    /**
     * 保存 扫单记录
     *
     * @param scanOrder
     * @return
     */
    int insert(ScanOrder scanOrder);


    /**
     * 获取惠商静默订单 未支付 待扫单列表
     *
     * @param scanTime
     * @param env
     * @return
     */
    List<Long> queryHsSilentScanOrderIds(@Param("scanTime") Date scanTime, @Param("env") String env);

    /**
     * 获取惠商审核通过 未支付 待扫单列表
     *
     * @param scanTime
     * @param env
     * @return
     */
    List<Long> queryHsAuditScanOrderIds(@Param("scanTime") Date scanTime, @Param("env") String env);

    /**
     * 获取惠商未审核 未支付  待扫单列表
     *
     * @param scanTime
     * @param env
     * @return
     */
    List<Long> queryHsUnAuditScanOrderIds(@Param("scanTime") Date scanTime, @Param("env") String env);

    /**
     * 更新扫单状态
     *
     * @param orderId
     * @param scanStatus
     * @return
     */
    int updateScanOrderStatus(@Param("orderId") Long orderId, @Param("scanStatus") int scanStatus);

    /**
     * 扫单成功 （更新状态、扫单次数、扫单时间）
     *
     * @param orderId
     * @return
     */
    int updateScanOrderSuccessStatus(@Param("orderId") Long orderId);


    /**
     * 支付系统回应可以进行扫单，更新待扫单状态
     *
     * @param orderId
     * @return
     */
    int updateScanOrderPendingStatus(@Param("orderId") Long orderId);


    /**
     * 扫单失败 （更新状态、扫单次数、扫单时间）
     *
     * @param orderId
     * @param code
     * @param reason
     * @return
     */
    int updateScanOrderFailStatus(@Param("orderId") Long orderId, @Param("code") String code, @Param("reason") String reason);

    /**
     * 扫单后确认订单已支付--挂起不再扫单 （更新状态、扫单次数、扫单时间）
     *
     * @param orderId
     * @param code
     * @param reason
     * @return
     */
    int updatePayOrderScanStatus(@Param("orderId") Long orderId, @Param("code") String code, @Param("reason") String reason);


    /**
     * 订单支付回调--更新扫单状态 4
     *
     * @param orderId
     * @return
     */
    int updatePaidCallbackScanStatus(@Param("orderId") Long orderId);

    /**
     * 支付回调晚，已进行扫单（扫单成功 或 扫单失败）---需报警
     *
     * @param orderId
     * @return
     */
    int updatePaidCallbackErrorScanStatus(@Param("orderId") Long orderId, @Param("code") String code, @Param("reason") String reason);

    /**
     * 更新惠商审单信息
     *
     * @param orderId
     * @param auditStatus
     * @param auditTime
     * @return
     */
    int updateHsAuditInfo(@Param("orderId") Long orderId, @Param("auditStatus") Integer auditStatus, @Param("auditTime") String auditTime);

    /**
     * 根据订单号查看待扫单信息
     *
     * @param orderId
     * @return
     */
    ScanOrder getScanOrderByOrderId(@Param("orderId") Long orderId);
}