package com.lenovo.m2.hsbuy.job.dao.order.pipeline;

import com.lenovo.m2.hsbuy.domain.order.mainorder.MDeliveryAddress;
import org.apache.ibatis.annotations.Param;

/**
 * Created by fenglg1 on 2016/2/24.
 */
public interface MDeliveryAddressMapper{

     MDeliveryAddress getMDeliveryAddressByOrderId(@Param("orderId") Long orderId);

}
