package com.lenovo.m2.hsbuy.job.dao.promotion;


public interface EppSalesGoodsPromotionRoleCheckMapper {
    int  updatePromotionIsUse();
}