package com.lenovo.m2.hsbuy.job.dao.address;


import com.lenovo.m2.hsbuy.job.domain.address.SmbAddress;

import java.util.List;

/**
 * Created by admin on 2017/7/25.
 * smb商城地址库
 */
public interface SmbAddressMapper {

    /**
     * 获取所有省市县乡镇信息
     * @return
     */
    public List<SmbAddress> getAll();

    /**
     * 删除数据库中四级地址信息
     * @return
     */
    public int deleteFourLevelSmbAddress();

    /**
     * 批量插入四级地址信息
     * @param list
     * @return
     */
    public int initBatchInsertFourLevelAddress(List<SmbAddress> list);

}
