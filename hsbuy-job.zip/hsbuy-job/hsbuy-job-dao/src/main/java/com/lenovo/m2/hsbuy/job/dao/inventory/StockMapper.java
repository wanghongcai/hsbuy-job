package com.lenovo.m2.hsbuy.job.dao.inventory;

import com.lenovo.m2.hsbuy.domain.inventory.StockInfo;

import java.util.List;

/**
 * Created by bob on 2015/7/6.
 */
public interface StockMapper {


    /**
     * 查询已上架的惠商在线库存列表
     * @return
     */
    List<StockInfo> getHsOnlineStock();

}
