package com.lenovo.m2.hsbuy.job.dao.order.pipeline;

import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderItem;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by fenglg1 on 2016/2/24.
 */
public interface MOrderItemMapper{

    List<MOrderItem> getMOrderItemByOrderId(@Param("orderId") Long orderId);

}
