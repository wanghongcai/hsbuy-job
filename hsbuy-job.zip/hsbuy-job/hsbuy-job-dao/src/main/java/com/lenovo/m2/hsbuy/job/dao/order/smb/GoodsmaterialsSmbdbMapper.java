package com.lenovo.m2.hsbuy.job.dao.order.smb;


import com.lenovo.m2.hsbuy.job.domain.order.Goodsmaterials;

import java.util.List;

/**
 * Created by zhaocl1 on 2016/8/17.
 */
public interface GoodsmaterialsSmbdbMapper {

    /**
     * 通过物料号和产品组获取物料类型
     *
     * @return
     */
    List<Goodsmaterials> selectMtart();

    /**
     * 通过物料号和产品组获取物料类型  增量数据
     *
     * @return
     */
    List<Goodsmaterials> selectMtartByCreateTime(String createTime);
}
