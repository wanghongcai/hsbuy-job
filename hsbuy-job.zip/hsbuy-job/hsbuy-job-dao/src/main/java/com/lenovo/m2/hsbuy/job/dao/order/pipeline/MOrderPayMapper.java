package com.lenovo.m2.hsbuy.job.dao.order.pipeline;

import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderPay;
import org.apache.ibatis.annotations.Param;

/**
 * Created by fenglg1 on 2016/2/25.
 */
public interface MOrderPayMapper {

    MOrderPay getMOrderPayByOrderId(@Param("orderId") Long orderId);
}
