package com.lenovo.m2.hsbuy.job.dao.order.pipeline;

import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderInvoice;
import org.apache.ibatis.annotations.Param;

/**
 * Created by fenglg1 on 2016/2/25.
 */
public interface MOrderInvoiceMapper {

    public MOrderInvoice getMOrderInvoiceByOrderId(@Param("orderId") Long orderId);

}
