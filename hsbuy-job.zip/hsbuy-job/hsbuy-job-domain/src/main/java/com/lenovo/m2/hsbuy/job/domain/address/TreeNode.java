package com.lenovo.m2.hsbuy.job.domain.address;


import com.lenovo.m2.hsbuy.job.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.job.common.util.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 多叉树实现省市县的查找修改等
 */
public class TreeNode implements java.io.Serializable {
    private String parentName;
    private String selfName;
    private String selfCode;
    protected String provinceId;
    protected String cityId;
    private String zip;
    protected List<TreeNode> childList;
    private TreeNode parentNode;
    private String addressId;
    public TreeNode() {
        initChildList();
    }

    public TreeNode(TreeNode parentNode) {
        this.getParentNode();
        initChildList();
    }

    private boolean isLeaf() {
        if (childList == null) {
            return true;
        } else {
            if (childList.isEmpty()) {
                return true;
            } else {
                return false;
            }
        }
    }

    /* 插入一个child节点到当前节点中 */
    public void addChildNode(TreeNode treeNode) {
        initChildList();
        treeNode.setParentName(this.selfName);
        childList.add(treeNode);
    }

    public void initChildList() {
        if (childList == null)
            childList = new ArrayList<TreeNode>();
    }

    private boolean isValidTree() {
        return true;
    }

    /* 返回当前节点的父辈节点集合 */
    private List<TreeNode> getElders() {
        List<TreeNode> elderList = new ArrayList<TreeNode>();
        TreeNode parentNode = this.getParentNode();
        if (parentNode == null) {
            return elderList;
        } else {
            elderList.add(parentNode);
            elderList.addAll(parentNode.getElders());
            return elderList;
        }
    }

    /* 返回当前节点的晚辈集合 */
    private List<TreeNode> getJuniors() {
        List<TreeNode> juniorList = new ArrayList<TreeNode>();
        List<TreeNode> childList = this.getChildList();
        if (childList == null) {
            return juniorList;
        } else {
            int childNumber = childList.size();
            for (int i = 0; i < childNumber; i++) {
                TreeNode junior = childList.get(i);
                juniorList.add(junior);
                juniorList.addAll(junior.getJuniors());
            }
            return juniorList;
        }
    }

    /* 返回当前节点的孩子集合 */
    public List<TreeNode> getChildList() {
        return childList;
    }

    /* 删除节点和它下面的晚辈 */
    public void deleteNode() {
        TreeNode parentNode = this.getParentNode();
        String name = this.getSelfName();

        if (parentNode != null) {
            parentNode.deleteChildNode(name);
        }
    }

    /* 删除当前节点的某个子节点 */
    public void deleteChildNode(String childName) {
        List<TreeNode> childList = this.getChildList();
        int childNumber = childList.size();
        for (int i = 0; i < childNumber; i++) {
            TreeNode child = childList.get(i);
            if (child.getSelfName().equals(childName)) {
                childList.remove(i);
                return;
            }
        }
    }

    /* 动态的插入一个新的节点到当前树中 */
    public boolean insertJuniorNode(TreeNode treeNode) {
        String juniorParentName = treeNode.getParentName();
        if (this.parentName.equals(juniorParentName)) {
            addChildNode(treeNode);
            return true;
        } else {
            List<TreeNode> childList = this.getChildList();
            int childNumber = childList.size();
            boolean insertFlag;

            for (int i = 0; i < childNumber; i++) {
                TreeNode childNode = childList.get(i);
                insertFlag = childNode.insertJuniorNode(treeNode);
                if (insertFlag == true)
                    return true;
            }
            return false;
        }
    }

    /* 找到一颗树中某个节点 */
    public TreeNode findTreeNodeById(String name) {
        if (this.selfName.equals(name))
            return this;
        if (childList.isEmpty() || childList == null) {
            return null;
        } else {
            int childNumber = childList.size();
            for (int i = 0; i < childNumber; i++) {
                TreeNode child = childList.get(i);
                TreeNode resultNode = child.findTreeNodeById(name);
                if (resultNode != null) {
                    return resultNode;
                }
            }
            return null;
        }
    }
    
   
    
    public TreeNode findTreeNodeById(String name,boolean containSelf,boolean onlyOneChild) {
        if (this.selfName.equals(name) && containSelf)
            return this;
        if (childList.isEmpty() || childList == null) {
            return null;
        } else {
            int childNumber = childList.size();
            for (int i = 0; i < childNumber; i++) {
                TreeNode child = childList.get(i);
                if(onlyOneChild){
                	if(!StringUtil.isEmpty(name) && name.equals(child.getSelfName())){
                		return child;
                	}
                }else{
	                TreeNode resultNode = child.findTreeNodeById(name);
	                if (resultNode != null) {
	                    return resultNode;
	                }
                }
            }
            return null;
        }
    }
    
    public TreeNode findTreeNodeByCode(String code) {
        if (this.selfCode.equals(code))
            return this;
        if (childList.isEmpty() || childList == null) {
            return null;
        } else {
            int childNumber = childList.size();
            for (int i = 0; i < childNumber; i++) {
                TreeNode child = childList.get(i);
                TreeNode resultNode = child.findTreeNodeByCode(code);
                if (resultNode != null) {
                    return resultNode;
                }
            }
            return null;
        }
    }
    
   

    /* 遍历一棵树，层次遍历 */
    public void traverse() {
        if (StringUtil.isEmpty(selfName))
            return;
        if (childList == null || childList.isEmpty())
            return;
        int childNumber = childList.size();
        for (int i = 0; i < childNumber; i++) {
            TreeNode child = childList.get(i);
            child.traverse();
        }
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public void print(String content) {
        System.out.println(content);
    }

    public void print(int content) {
        System.out.println(String.valueOf(content));
    }

    public void setChildList(List<TreeNode> childList) {
        this.childList = childList;
    }

    private String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getSelfName() {
        return selfName;
    }

    public void setSelfName(String selfName) {
        this.selfName = selfName;
    }

    private TreeNode getParentNode() {
        return parentNode;
    }

    public void setParentNode(TreeNode parentNode) {
        this.parentNode = parentNode;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(String provinceId) {
        this.provinceId = provinceId;
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }
    
    

    public String getSelfCode() {
		return selfCode;
	}

	public void setSelfCode(String selfCode) {
		this.selfCode = selfCode;
	}

    @Override
    public String toString() {
        return "TreeNode{" +
                "parentName='" + parentName + '\'' +
                ", selfName='" + selfName + '\'' +
                ", selfCode='" + selfCode + '\'' +
                ", provinceId='" + provinceId + '\'' +
                ", cityId='" + cityId + '\'' +
                ", zip='" + zip + '\'' +
                ", childList=" + childList +
                ", parentNode=" + parentNode +
                ", addressId='" + addressId + '\'' +
                '}';
    }

    public  static void main(String args[]){
        TreeNode root = new TreeNode();
        root.setSelfName("root");
        TreeNode t1 = new TreeNode();
        //t1.setParentNode(root);
        t1.setSelfName("广西");
        t1.setProvinceId("010");
        root.addChildNode(t1);
        TreeNode t11 = new TreeNode();
        //t11.setParentNode(t1);
        t11.setSelfName("河池市");
        t1.addChildNode(t11);

        TreeNode t12 = new TreeNode();
        //t12.setParentNode(t11);
        t12.setSelfName("金城江区");
        t11.addChildNode(t12);
        TreeNode t13 = new TreeNode();
        //t13.setParentNode(t11);
        t13.setSelfName("白土乡");
        t12.addChildNode(t13);

        TreeNode t2 = new TreeNode();
        //t2.setParentNode(root);
        t2.setSelfName("北京");
        t2.setProvinceId("100");
        root.addChildNode(t2);

        System.out.println("==="+ JsonUtil.toJson(root));
        System.out.println("---"+ JsonUtil.toJson(root.findTreeNodeById("root").findTreeNodeById("北京").getProvinceId()));
        String t = "{\"selfName\":\"root\",\"provinceId\":null,\"zip\":null,\"childList\":[{\"selfName\":\"广西\",\"provinceId\":\"010\",\"zip\":null,\"childList\":[{\"selfName\":\"河池市\",\"provinceId\":null,\"zip\":null,\"childList\":[{\"selfName\":\"金城江区\",\"provinceId\":null,\"zip\":null,\"childList\":[{\"selfName\":\"白土乡\",\"provinceId\":null,\"zip\":null,\"childList\":[]}]}]}]},{\"selfName\":\"北京\",\"provinceId\":\"100\",\"zip\":null,\"childList\":[]}]}";

        TreeNode node = JsonUtil.fromJson(t, TreeNode.class);


    }
}
