package com.lenovo.m2.hsbuy.job.domain.address;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by admin on 2017/7/25.
 */
public class HsAddress implements Serializable {
    //主键ID
    private int id;
    //省份
    private String proviceName;
    //省份编号
    private String proviceNo;
    //城市名称
    private String cityName;
    //城市编号
    private String cityNo;
    //县名称
    private String districName;
    //县编号
    private String districNo;
    //创建时间
    private Date createTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProviceName() {
        return proviceName;
    }

    public void setProviceName(String proviceName) {
        this.proviceName = proviceName;
    }

    public String getProviceNo() {
        return proviceNo;
    }

    public void setProviceNo(String proviceNo) {
        this.proviceNo = proviceNo;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCityNo() {
        return cityNo;
    }

    public void setCityNo(String cityNo) {
        this.cityNo = cityNo;
    }

    public String getDistricName() {
        return districName;
    }

    public void setDistricName(String districName) {
        this.districName = districName;
    }

    public String getDistricNo() {
        return districNo;
    }

    public void setDistricNo(String districNo) {
        this.districNo = districNo;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
