package com.lenovo.m2.hsbuy.job.domain.order;

/**
 * <pre>
 *    author  : licy13
 *    email   : licy13@lenovo.com
 *    time    : 2017/9/28 21:11
 *    desc    : 惠商审单信息
 *    version : v1.0
 * </pre>
 */
public class HsAuditInfo {

    //订单号
    private Long orderCode;
    //商城
    private Integer shopId;
    //审核状态
    private Boolean pass;
    //审单时间
    private String auditTime;

    public Long getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(Long orderCode) {
        this.orderCode = orderCode;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public Boolean getPass() {
        return pass;
    }

    public void setPass(Boolean pass) {
        this.pass = pass;
    }

    public String getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(String auditTime) {
        this.auditTime = auditTime;
    }

    @Override
    public String toString() {
        return "HsAuditInfo{" +
                "orderCode=" + orderCode +
                ", shopId=" + shopId +
                ", pass=" + pass +
                ", auditTime='" + auditTime + '\'' +
                '}';
    }
}
