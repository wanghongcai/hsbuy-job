package com.lenovo.m2.hsbuy.job.domain.order;

import java.io.Serializable;

/**
 * Created by zhaocl1 on 2016/8/3.
 */
public class Goodsmaterials implements Serializable {

    private static final long serialVersionUID = 4788028464763936552L;
    /**
     * 主键
     */
    private String id;
    /**
     * 物料号
     */
    private String lenovoMaterialNumber;
    /**
     * 产品组
     */
    private String productGroupNo;
    /**
     * 物料类型
     */
    private String mtart;
    /**
     * 订单原因
     */
    private String augru;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLenovoMaterialNumber() {
        return lenovoMaterialNumber;
    }

    public void setLenovoMaterialNumber(String lenovoMaterialNumber) {
        this.lenovoMaterialNumber = lenovoMaterialNumber;
    }

    public String getProductGroupNo() {
        return productGroupNo;
    }

    public void setProductGroupNo(String productGroupNo) {
        this.productGroupNo = productGroupNo;
    }

    public String getMtart() {
        return mtart;
    }

    public void setMtart(String mtart) {
        this.mtart = mtart;
    }

    public String getAugru() {
        return augru;
    }

    public void setAugru(String augru) {
        this.augru = augru;
    }

    @Override
    public String toString() {
        return "Goodsmaterials{" +
                "id='" + id + '\'' +
                ", lenovoMaterialNumber='" + lenovoMaterialNumber + '\'' +
                ", productGroupNo='" + productGroupNo + '\'' +
                ", mtart='" + mtart + '\'' +
                ", augru='" + augru + '\'' +
                '}';
    }
}
