package com.lenovo.m2.hsbuy.job.domain.order;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *    author  : licy13
 *    email   : licy13@lenovo.com
 *    time    : 2017/9/27 18:07
 *    desc    :  扫单记录表
 *    version : v1.0
 * </pre>
 */
public class ScanOrder implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     *  自增主键
     */
    private Long id;

    /**
     * 订单号
     */
    private Long orderId;

    /**
     *
     */
    private Long lenovoId;


    /**
     * 订单类型
     */
    private Integer orderType;


    /**
     * 支付方式  0 在线支付 1 货到付款 2 线下银行转账
     */
    private Integer paymentType;

    /**
     *
     */
    private Integer shopId;

    /**
     * 扫单次数
     */
    private Integer times;

    /**
     * 失败码
     */
    private String code;

    /**
     * 失败原因
     */
    private String reason;

    /**
     * 扫单状态
     */
    private Integer scanStatus;

    /**
     * 下单方式 静默 非静默
     */
    private Integer submitOrderWay;

    /**
     * 审核状态
     */
    private Integer auditStatus;

    /**
     * 审核时间
     */
    private Date auditTime;

    /**
     * 下单时间
     */
    private Date orderTime;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 版本号
     */
    private Integer version;

    /**
     * 环境变量：docker-product,docker-preprod,docker-uat-new
     */
    private String env;


    public Integer getScanStatus() {
        return scanStatus;
    }

    public void setScanStatus(Integer scanStatus) {
        this.scanStatus = scanStatus;
    }

    public Integer getSubmitOrderWay() {
        return submitOrderWay;
    }

    public void setSubmitOrderWay(Integer submitOrderWay) {
        this.submitOrderWay = submitOrderWay;
    }

    public Integer getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(Integer auditStatus) {
        this.auditStatus = auditStatus;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public Integer getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(Integer paymentType) {
        this.paymentType = paymentType;
    }

    /**
     * @return Id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }


    /**
     * 扫单次数
     *
     * @return Times 扫单次数
     */
    public Integer getTimes() {
        return times;
    }

    /**
     * 扫单次数
     *
     * @param times 扫单次数
     */
    public void setTimes(Integer times) {
        this.times = times;
    }

    /**
     * 失败码
     *
     * @return Code 失败码
     */
    public String getCode() {
        return code;
    }

    /**
     * 失败码
     *
     * @param code 失败码
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 失败原因
     *
     * @return Reason 失败原因
     */
    public String getReason() {
        return reason;
    }

    /**
     * 失败原因
     *
     * @param reason 失败原因
     */
    public void setReason(String reason) {
        this.reason = reason;
    }


    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(Long lenovoId) {
        this.lenovoId = lenovoId;
    }

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public Date getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(Date orderTime) {
        this.orderTime = orderTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * 版本号
     *
     * @return Version 版本号
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * 版本号
     *
     * @param version 版本号
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * 环境变量：docker-product,docker-preprod,docker-uat-new
     *
     * @return Env 环境变量：docker-product,docker-preprod,docker-uat-new
     */
    public String getEnv() {
        return env;
    }

    /**
     * 环境变量：docker-product,docker-preprod,docker-uat-new
     *
     * @param env 环境变量：docker-product,docker-preprod,docker-uat-new
     */
    public void setEnv(String env) {
        this.env = env;
    }


}
