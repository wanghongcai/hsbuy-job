package com.lenovo.m2.hsbuy.job.manager.order.smb;


import com.lenovo.m2.hsbuy.job.domain.order.Goodsmaterials;

import java.util.List;

/**
 * Created by zhaocl1 on 2016/8/17.
 */
public interface GoodsmaterialsManager {

    /**
     * 批量插入
     * @param list
     * @return
     */
    int saveGoodsmaterialsTempBatch(List<Goodsmaterials> list);

    /**
     * 更换表名
     * @return
     */
    void swap_goodsmaterials_name();

    /**
     * 删除临时表的数据
     */
    void delete_goodsmaterials_temp();

    /**
     * 保存物料信息
     * @param list
     * @return
     */
    int saveSmbGoodsmaterials(List<Goodsmaterials> list);

    /**
     * 批量插入
     * @param list
     * @return
     */
    int saveGoodsmaterialsBatch(List<Goodsmaterials> list);

    /**
     * 保存物料信息
     * @param list
     * @return
     */
    int saveSmbGoodsmaterialsByCreateTime(List<Goodsmaterials> list);


}
