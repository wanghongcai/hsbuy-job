package com.lenovo.m2.hsbuy.job.manager.inventory;

import com.lenovo.m2.hsbuy.domain.inventory.StockInfo;

import java.util.List;

/**
 * Created by bob on 2015/7/3.
 */
public interface StockManager {
    /**
     * 查询上架状态的惠商库存的列表
     * @return
     */
    List<StockInfo> getHsOnlineStock();

}
