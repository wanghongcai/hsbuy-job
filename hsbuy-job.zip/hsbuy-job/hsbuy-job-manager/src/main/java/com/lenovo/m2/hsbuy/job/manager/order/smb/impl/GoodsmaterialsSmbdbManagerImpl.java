package com.lenovo.m2.hsbuy.job.manager.order.smb.impl;

import com.lenovo.m2.hsbuy.job.dao.order.smb.GoodsmaterialsSmbdbMapper;
import com.lenovo.m2.hsbuy.job.domain.order.Goodsmaterials;
import com.lenovo.m2.hsbuy.job.manager.order.smb.GoodsmaterialsSmbdbManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by zhaocl1 on 2016/8/17.
 */
@Component("goodsmaterialsSmbdbManager")
public class GoodsmaterialsSmbdbManagerImpl implements GoodsmaterialsSmbdbManager {

    @Autowired
    private GoodsmaterialsSmbdbMapper goodsmaterialsSmbdbMapper;
    @Override
    public List<Goodsmaterials> selectMtart() {
        return goodsmaterialsSmbdbMapper.selectMtart();
    }

    @Override
    public List<Goodsmaterials> selectMtartByCreateTime(String createTime) {
        return goodsmaterialsSmbdbMapper.selectMtartByCreateTime(createTime);
    }
}
