package com.lenovo.m2.hsbuy.job.manager.promotion.impl;

import com.lenovo.m2.hsbuy.job.dao.promotion.EppSalesGoodsPromotionRoleCheckMapper;
import com.lenovo.m2.hsbuy.job.dao.promotion.PromotionMapper;
import com.lenovo.m2.hsbuy.job.manager.promotion.PromotionIsUseJobManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * Created by luqian on 2015-12-05.
 */
@Component
public class PromotionIsUseJobManagerImpl implements PromotionIsUseJobManager {

    Logger log = LoggerFactory.getLogger(PromotionIsUseJobManagerImpl.class);
    
    @Autowired
    private PromotionMapper promotionMapper;
    @Autowired
    private EppSalesGoodsPromotionRoleCheckMapper eppSalesGoodsPromotionRoleCheckMapper;

    @Override
    public void updatePromotionIsUse() {
        try{
             promotionMapper.updatePromotionIsUse();
            eppSalesGoodsPromotionRoleCheckMapper.updatePromotionIsUse();
        } catch (Exception e){
            log.error("更新促销停用状态异常！", e);
        }
    }
}
