package com.lenovo.m2.hsbuy.job.manager.promotion;

/**
 * Created by luqian on 2015-12-05.
 */
public interface PromotionIsUseJobManager {

    public void updatePromotionIsUse();

}
