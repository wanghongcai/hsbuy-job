package com.lenovo.m2.hsbuy.job.manager.order.pipeline;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.job.domain.order.HsAuditInfo;
import com.lenovo.m2.hsbuy.job.domain.order.ScanOrder;


import java.util.List;

/**
 * <pre>
 *    author  : licy13
 *    email   : licy13@lenovo.com
 *    time    : 2017/9/27 18:49
 *    desc    : 输入描述
 *    version : v1.0
 * </pre>
 */
public interface ScanOrderManager {

    /**
     * 获取惠商未审核 未支付  待扫单列表
     *
     * @param scanMinutesTime
     * @param env
     * @return
     */
    public RemoteResult<List<Long>> queryHsUnAuditScanOrderIds(int scanMinutesTime, String env);

    /**
     * 获取惠商审核通过 未支付 待扫单列表
     *
     * @param scanMinutesTime
     * @param env
     * @return
     */
    public RemoteResult<List<Long>> queryHsAuditScanOrderIds(int scanMinutesTime, String env);

    /**
     * 惠商静默订单
     *
     * @param scanMinutesTime
     * @param env
     * @return
     */
    public RemoteResult<List<Long>> queryHsSilentScanOrderIds(int scanMinutesTime, String env);


    /**
     * 保存扫单记录
     *
     * @param scanOrder
     */
    public RemoteResult<Integer> saveScanOrderRecord(ScanOrder scanOrder);

    /**
     * 根据订单号 更新支付回调 的扫单状态
     *
     * @param orderId
     * @return
     */
    public RemoteResult<Integer> updatePaidCallbackOrderScanStatus(Long orderId);

    /**
     * 更新扫单状态
     *
     * @param orderId
     * @param scanStatus
     * @return
     */
    public RemoteResult<Integer> updateScanOrderStatus(Long orderId, int scanStatus);

    /**
     * 扫单成功 （更新状态、扫单次数、扫单时间）
     *
     * @param orderId
     * @return
     */
    public RemoteResult<Integer> updateScanOrderSuccessStatus(Long orderId);


    /**
     * 支付系统回应可以进行扫单，更新待扫单状态
     *
     * @param orderId
     * @return
     */
    public RemoteResult<Integer> updateScanOrderPendingStatus(Long orderId);


    /**
     * 扫单失败 （更新状态、扫单次数、扫单时间）
     *
     * @param orderId
     * @param code
     * @param reason
     * @return
     */
    public RemoteResult<Integer> updateScanOrderFailStatus(Long orderId, String code, String reason);


    /**
     * 扫单后确认订单已支付--挂起不再扫单 （更新状态、扫单次数、扫单时间）
     *
     * @param orderId
     * @param code
     * @param reason
     * @return
     */
    public RemoteResult<Integer> updatePayOrderScanStatus(Long orderId, String code, String reason);

    /**
     * 更新惠商审单信息异常
     *
     * @param hsAuditInfo
     * @return
     */
    public RemoteResult updateHsAuditInfo(HsAuditInfo hsAuditInfo);
}
