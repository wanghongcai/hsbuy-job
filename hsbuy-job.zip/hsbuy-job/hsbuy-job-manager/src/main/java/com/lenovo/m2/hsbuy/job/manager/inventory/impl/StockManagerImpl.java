package com.lenovo.m2.hsbuy.job.manager.inventory.impl;


import com.lenovo.m2.hsbuy.domain.inventory.StockInfo;
import com.lenovo.m2.hsbuy.job.dao.inventory.StockMapper;
import com.lenovo.m2.hsbuy.job.manager.inventory.StockManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;

/**
 * Created by bob on 2015/7/3.
 */
@Component("stockManager")
public class StockManagerImpl implements StockManager {
    @Autowired
    private StockMapper stockMapper;


    @Override
    public List<StockInfo> getHsOnlineStock() {
        return stockMapper.getHsOnlineStock();
    }

}
