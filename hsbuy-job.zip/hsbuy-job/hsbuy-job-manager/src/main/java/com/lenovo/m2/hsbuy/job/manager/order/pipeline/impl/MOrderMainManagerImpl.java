package com.lenovo.m2.hsbuy.job.manager.order.pipeline.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

import com.lenovo.m2.hsbuy.domain.order.mainorder.MDeliveryAddress;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderInvoice;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderItem;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderMain;
import com.lenovo.m2.hsbuy.domain.order.orderInfo.MainOrderInfo;
import com.lenovo.m2.hsbuy.job.common.order.enums.ResultMessageEnum;
import com.lenovo.m2.hsbuy.job.common.order.utils.RemoteResultFactory;
import com.lenovo.m2.hsbuy.job.dao.order.pipeline.*;
import com.lenovo.m2.hsbuy.job.manager.order.pipeline.MOrderMainManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by zhaocl1 on 2016/8/27.
 */
@Service
public class MOrderMainManagerImpl implements MOrderMainManager {

    private final static Logger LOGGER = LogManager.getLogger();
    @Autowired
    private MOrderMainMapper mOrderMainMapper;
    @Autowired
    private MOrderItemMapper mOrderItemMapper;
    @Autowired
    private MOrderInvoiceMapper mOrderInvoiceMapper;
    @Autowired
    private MDeliveryAddressMapper mDeliveryAddressMapper;
    @Autowired
    private MOrderPayMapper mOrderPayMapper;

    @Override
    public MainOrderInfo getMainOrderInfo(Long orderId) {
        MainOrderInfo mainOrderInfo = new MainOrderInfo();
        MOrderMain mOrderMain = mOrderMainMapper.getOrderMainByOrderID(orderId);
        List<MOrderItem> list = mOrderItemMapper.getMOrderItemByOrderId(orderId);
        MDeliveryAddress mDeliveryAddress = mDeliveryAddressMapper.getMDeliveryAddressByOrderId(orderId);
        MOrderInvoice mOrderInvoice = mOrderInvoiceMapper.getMOrderInvoiceByOrderId(orderId);
        mainOrderInfo.setM_OrderMain(mOrderMain);
        mainOrderInfo.setM_OrderItemList(list);
        mainOrderInfo.setM_DeliveryAddress(mDeliveryAddress);
        mainOrderInfo.setM_OrderInvoice(mOrderInvoice);
        return mainOrderInfo;
    }

    @Override
    public List<MOrderMain> getExceptionMOrderMain() {
        return mOrderMainMapper.getExceptionMOrderMain();
    }


    /**
     * 根据订单号获取一拆订单信息
     *
     * @param orderCode
     * @return
     */
    @Override
    public RemoteResult getMOrderMainByOrderCode(Long orderCode) {
        try {
            MOrderMain mOrderMain = mOrderMainMapper.getOrderMainByOrderCode(orderCode);
            return RemoteResultFactory.getSuccessResult(mOrderMain);
        } catch(Exception e) {
            LOGGER.error("getMOrderMainByOrderCode error orderCode=" + orderCode, e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, orderCode + "获取一拆订单信息异常");
        }

    }
}
