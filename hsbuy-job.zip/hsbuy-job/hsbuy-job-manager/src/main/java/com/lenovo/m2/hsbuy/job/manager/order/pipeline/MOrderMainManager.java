package com.lenovo.m2.hsbuy.job.manager.order.pipeline;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderMain;
import com.lenovo.m2.hsbuy.domain.order.orderInfo.MainOrderInfo;


import java.util.List;

/**
 * Created by zhaocl1 on 2016/8/27.
 */
public interface MOrderMainManager {

    /**
     * 根据订单号获取一拆订单信息
     * @param orderCode
     * @return
     */
    RemoteResult<MOrderMain> getMOrderMainByOrderCode(Long orderCode);


    MainOrderInfo getMainOrderInfo(Long orderId);

    //获取二拆异常订单
    List<MOrderMain> getExceptionMOrderMain();
}
