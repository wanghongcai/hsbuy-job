package com.lenovo.m2.hsbuy.job.manager.order.pipeline.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.job.common.order.enums.ResultMessageEnum;
import com.lenovo.m2.hsbuy.job.common.order.utils.RemoteResultFactory;
import com.lenovo.m2.hsbuy.job.dao.order.pipeline.ScanOrderMapper;
import com.lenovo.m2.hsbuy.job.domain.order.HsAuditInfo;
import com.lenovo.m2.hsbuy.job.domain.order.ScanOrder;
import com.lenovo.m2.hsbuy.job.manager.order.pipeline.ScanOrderManager;
import org.apache.commons.lang.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * <pre>
 *    author  : licy13
 *    email   : licy13@lenovo.com
 *    time    : 2017/9/27 18:49
 *    desc    : 输入描述
 *    version : v1.0
 * </pre>
 */
@Service
public class ScanOrderManagerImpl implements ScanOrderManager {

    private final static Logger LOGGER = LogManager.getLogger();


    @Autowired
    private ScanOrderMapper scanOrderMapper;


    /**
     * 获取惠商未审核 未支付  待扫单列表
     *
     * @param scanMinutesTime
     * @param env
     * @return
     */
    @Override
    public RemoteResult queryHsUnAuditScanOrderIds(int scanMinutesTime, String env) {
        Date scanTime = null;
        try {
            //转换成时间
            scanTime = DateUtils.addMinutes(new Date(), -scanMinutesTime);
            List<Long> waitScanOrder = scanOrderMapper.queryHsUnAuditScanOrderIds(scanTime, env);
            return RemoteResultFactory.getSuccessResult(waitScanOrder);
        } catch(Exception e) {
            LOGGER.error("queryHsSilentScanOrderIds error ,scanTime=" + scanTime + ",env=" + env, e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "获取惠商未审核待扫单订单号异常");
        }
    }

    /**
     * 获取惠商审核通过 未支付 待扫单列表
     *
     * @param scanMinutesTime
     * @param env
     * @return
     */
    @Override
    public RemoteResult queryHsAuditScanOrderIds(int scanMinutesTime, String env) {
        Date scanTime = null;
        try {
            //转换成时间
            scanTime = DateUtils.addMinutes(new Date(), -scanMinutesTime);
            List<Long> waitScanOrder = scanOrderMapper.queryHsAuditScanOrderIds(scanTime, env);
            return RemoteResultFactory.getSuccessResult(waitScanOrder);
        } catch(Exception e) {
            LOGGER.error("queryHsSilentScanOrderIds error ,scanTime=" + scanTime + ",env=" + env, e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "获取惠商审核通过待扫单订单号异常");
        }
    }

    /**
     * 获取惠商静默订单 未支付 待扫单列表
     *
     * @param scanMinutesTime
     * @param env
     * @return
     */
    @Override
    public RemoteResult queryHsSilentScanOrderIds(int scanMinutesTime, String env) {
        Date scanTime = null;
        try {
            //转换成时间
            scanTime = DateUtils.addMinutes(new Date(), -scanMinutesTime);
            List<Long> waitScanOrder = scanOrderMapper.queryHsSilentScanOrderIds(scanTime, env);
            return RemoteResultFactory.getSuccessResult(waitScanOrder);
        } catch(Exception e) {
            LOGGER.error("queryHsSilentScanOrderIds error ,scanTime=" + scanTime + ",env=" + env, e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "获取惠商静默待扫单订单号异常");
        }
    }

    /**
     * 保存扫单记录
     *
     * @param scanOrder
     */
    @Override
    public RemoteResult saveScanOrderRecord(ScanOrder scanOrder) {
        LOGGER.info("saveScanOrderRecord params scanOrder={}", scanOrder);
        try {
            int i = scanOrderMapper.insert(scanOrder);
            return RemoteResultFactory.getSuccessResult(i);
        } catch(Exception e) {
            LOGGER.error("updatePaidOrderScanStatus error orderId=" + scanOrder.getOrderId(), e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, scanOrder.getOrderId() + "保存扫单记录异常");
        }
    }

    /**
     * 根据订单号更新支付订单号扫单状态
     *
     * @param orderId
     * @return
     */
    @Override
    public RemoteResult updatePaidCallbackOrderScanStatus(Long orderId) {
        try {
            //先查询扫单库是否有该订单，因为惠商线下转账的订单 不扫单 不进扫单库
            ScanOrder scanOrder = scanOrderMapper.getScanOrderByOrderId(orderId);
            if (scanOrder == null) {
                return RemoteResultFactory.getSuccessResult(0);
            }

            int i = scanOrderMapper.updatePaidCallbackScanStatus(orderId);
            //更新 0 条表示 支付回调晚，已经扫单
            if (i == 0) {
                //异常单更新状态
                i = scanOrderMapper.updatePaidCallbackErrorScanStatus(orderId, ResultMessageEnum.ERROR_PAID_CALLBACK_SLOW.getCode(), ResultMessageEnum.ERROR_PAID_CALLBACK_SLOW.getDesc());
            }
            return RemoteResultFactory.getSuccessResult(i);
        } catch(Exception e) {
            LOGGER.error("updatePaidOrderScanStatus error orderId=" + orderId, e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, orderId + "支付回调更新扫单状态异常");
        }
    }


    /**
     * 更新扫单状态
     *
     * @param orderId
     * @param scanStatus
     * @return
     */
    @Override
    public RemoteResult updateScanOrderStatus(Long orderId, int scanStatus) {
        try {
            int i = scanOrderMapper.updateScanOrderStatus(orderId, scanStatus);
            return RemoteResultFactory.getSuccessResult(i);
        } catch(Exception e) {
            LOGGER.error("updateScanOrderStatus error orderId=" + orderId, e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, orderId + "更新扫单状态异常");
        }
    }

    /**
     * 扫单成功 （更新状态、扫单次数、扫单时间）
     *
     * @param orderId
     * @return
     */
    @Override
    public RemoteResult updateScanOrderSuccessStatus(Long orderId) {
        try {
            int i = scanOrderMapper.updateScanOrderSuccessStatus(orderId);
            //更新 0 条表示 支付回调晚，已经扫单
            if (i == 0) {
                //异常单更新状态
                i = scanOrderMapper.updatePaidCallbackErrorScanStatus(orderId, ResultMessageEnum.ERROR_PAID_CALLBACK_SLOW.getCode(), ResultMessageEnum.ERROR_PAID_CALLBACK_SLOW.getDesc());
            }
            return RemoteResultFactory.getSuccessResult(i);
        } catch(Exception e) {
            LOGGER.error("updateScanOrderSuccessStatus error orderId=" + orderId, e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, orderId + "更新扫单成功状态异常");
        }
    }

    /**
     * 支付系统回应可以进行扫单，更新待扫单状态
     *
     * @param orderId
     * @return
     */
    @Override
    public RemoteResult updateScanOrderPendingStatus(Long orderId) {
        try {
            int i = scanOrderMapper.updateScanOrderPendingStatus(orderId);
            return RemoteResultFactory.getSuccessResult(i);
        } catch(Exception e) {
            LOGGER.error("updateScanOrderPendingStatus error orderId=" + orderId, e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, orderId + "更新待扫单状态异常");
        }
    }

    /**
     * 扫单失败 （更新状态、扫单次数、扫单时间）
     *
     * @param orderId
     * @param code
     * @param reason
     * @return
     */
    @Override
    public RemoteResult updateScanOrderFailStatus(Long orderId, String code, String reason) {
        try {
            int i = scanOrderMapper.updateScanOrderFailStatus(orderId, code, reason);
            //更新 0 条表示 支付回调晚，已经扫单
            if (i == 0) {
                //异常单更新状态
                i = scanOrderMapper.updatePaidCallbackErrorScanStatus(orderId, ResultMessageEnum.ERROR_PAID_CALLBACK_SLOW_FAIL.getCode(), ResultMessageEnum.ERROR_PAID_CALLBACK_SLOW_FAIL.getDesc() + " {" + code + "}: " + reason);
            }
            return RemoteResultFactory.getSuccessResult(i);
        } catch(Exception e) {
            LOGGER.error("updateScanOrderFailStatus error orderId=" + orderId, e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, orderId + "更新扫单失败状态异常");
        }
    }

    /**
     * 扫单后确认订单已支付--挂起不再扫单 （更新状态、扫单次数、扫单时间）
     *
     * @param orderId
     * @param code
     * @param reason
     * @return
     */
    @Override
    public RemoteResult updatePayOrderScanStatus(Long orderId, String code, String reason) {
        try {
            int i = scanOrderMapper.updatePayOrderScanStatus(orderId, code, reason);
            return RemoteResultFactory.getSuccessResult(i);
        } catch(Exception e) {
            LOGGER.error("updatePayOrderScanStatus error orderId=" + orderId, e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, orderId + "更新订单已支付状态异常");
        }
    }

    /**
     * 更新惠商审单信息异常
     *
     * @param hsAuditInfo
     * @return
     */
    @Override
    public RemoteResult updateHsAuditInfo(HsAuditInfo hsAuditInfo) {
        try {
            int i = scanOrderMapper.updateHsAuditInfo(hsAuditInfo.getOrderCode(),hsAuditInfo.getPass() ? 1 : 0 , hsAuditInfo.getAuditTime());
            return RemoteResultFactory.getSuccessResult(i);
        } catch(Exception e) {
            LOGGER.error("updateHsAuditInfo error orderId=" + hsAuditInfo.getOrderCode(), e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, hsAuditInfo.getOrderCode() + "更新惠商审单信息异常");
        }
    }


}
