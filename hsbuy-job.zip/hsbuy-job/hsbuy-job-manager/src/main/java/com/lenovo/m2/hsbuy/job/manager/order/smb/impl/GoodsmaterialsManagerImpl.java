package com.lenovo.m2.hsbuy.job.manager.order.smb.impl;

import com.lenovo.m2.hsbuy.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.job.dao.order.pipeline.GoodsmaterialsMapper;
import com.lenovo.m2.hsbuy.job.domain.order.Goodsmaterials;
import com.lenovo.m2.hsbuy.job.manager.order.smb.GoodsmaterialsManager;
import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhaocl1 on 2016/8/17.
 */
@Component("goodsmaterialsManager")
public class GoodsmaterialsManagerImpl implements GoodsmaterialsManager {
    private static final Logger logger = Logger.getLogger(GoodsmaterialsManagerImpl.class);
    @Autowired
    private GoodsmaterialsMapper goodsmaterialsMapper;

    @Override
    public int saveGoodsmaterialsTempBatch(List<Goodsmaterials> list) {
        return goodsmaterialsMapper.saveGoodsmaterialsTempBatch(list);
    }

    @Override
    public void swap_goodsmaterials_name() {
        goodsmaterialsMapper.swap_goodsmaterials_name();
    }

    @Override
    public void delete_goodsmaterials_temp() {
        goodsmaterialsMapper.delete_goodsmaterials_temp();
    }

    @Override
    @Transactional(value = "smb", rollbackFor = Exception.class)
    public int saveSmbGoodsmaterials(List<Goodsmaterials> list) {
        if (CollectionUtils.isNotEmpty(list)) {
            long t1 = System.currentTimeMillis();
            goodsmaterialsMapper.delete_goodsmaterials_temp();
            long t2 = System.currentTimeMillis();
            logger.info("---------delete 花费时间：" + (t2 - t1) + "ms");
            goodsmaterialsMapper.saveGoodsmaterialsTempBatch(list);
            long t3 = System.currentTimeMillis();
            logger.info("---------save 花费时间：" + (t3 - t2) + "ms");
            goodsmaterialsMapper.swap_goodsmaterials_name();
            logger.info("---------swap 花费时间：" + (System.currentTimeMillis() - t3) + "ms");
        }
        return 1;
    }

    @Override
    public int saveGoodsmaterialsBatch(List<Goodsmaterials> list) {
        return 0;
    }

    @Override
    @Transactional(value = "smb", rollbackFor = Exception.class)
    public int saveSmbGoodsmaterialsByCreateTime(List<Goodsmaterials> list) {
        int row = 0;
        int updateRow = 0;
        List<Goodsmaterials> goodsmaterialsList = new ArrayList<Goodsmaterials>();
        List<Goodsmaterials> editGoodsmaterialsList = new ArrayList<Goodsmaterials>();
        for(Goodsmaterials g : list) {
            Goodsmaterials goodsmaterials = goodsmaterialsMapper.selectMtartById(g.getId());
            if (goodsmaterials != null && goodsmaterials.getId().equals(g.getId())) {
                logger.info("<===========物料信息：" + JsonUtil.toJson(g) + "=========>");
                //如果已经存在则跳出
                if(goodsmaterials.getLenovoMaterialNumber().equals(g.getLenovoMaterialNumber())){
                    logger.info("--------物料类型id=" + g.getId() + "----已经存在。------");
                }else{
                    logger.info("<==========预更新物料，物料类型id=" + g.getId() + "==========>");
                    editGoodsmaterialsList.add(g);
                }
                continue;
            }
            //管道库中没有的物料类型数据
            goodsmaterialsList.add(g);
        }

        if (CollectionUtils.isNotEmpty(goodsmaterialsList)) {
            row = goodsmaterialsMapper.saveGoodsmaterialsBatch(goodsmaterialsList);
            logger.info("-------转移增量数据到数据库成功，数量=" + row);
        }

        if (CollectionUtils.isNotEmpty(editGoodsmaterialsList)) {
            for(Goodsmaterials goodsmaterials:editGoodsmaterialsList){
                updateRow = updateRow + goodsmaterialsMapper.updateGoodsmaterials(goodsmaterials);
            }
            logger.info("<==========更新物料数据到数据库成功，数量=" + updateRow + "==========>");
        }

        return row + updateRow;
    }
}
