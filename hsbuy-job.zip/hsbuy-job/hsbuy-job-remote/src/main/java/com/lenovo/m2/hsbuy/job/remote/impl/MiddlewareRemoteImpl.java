package com.lenovo.m2.hsbuy.job.remote.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.job.common.order.enums.ResultMessageEnum;
import com.lenovo.m2.hsbuy.job.common.order.utils.RemoteResultFactory;
import com.lenovo.m2.hsbuy.job.remote.MiddleWareRemote;
import com.lenovo.m2.hsbuy.middleware.OrderMiddlewareService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * update by licy13 on 2017/9/28
 */
@Service
public class MiddlewareRemoteImpl implements MiddleWareRemote {
    private final static Logger LOGGER = LogManager.getLogger();

    @Autowired
    private OrderMiddlewareService orderMiddlewareService;


    @Override
    public RemoteResult cancelOrder(long orderCode, int type, int shopId) {
        try {
            return orderMiddlewareService.cancelOrder(orderCode, type, shopId);
        } catch(Exception e) {
            LOGGER.error("cancelOrder error 调用soa服务异常", e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "调用soa服务异常");
        }
    }

}
