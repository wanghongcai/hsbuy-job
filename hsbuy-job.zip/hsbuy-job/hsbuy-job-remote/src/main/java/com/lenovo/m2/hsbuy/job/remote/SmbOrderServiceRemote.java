package com.lenovo.m2.hsbuy.job.remote;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

import java.util.List;

/**
 * @Author licy13
 * @Date 2017/7/28
 */

public interface SmbOrderServiceRemote {

    /**
     * 获取smb待抛单 smb单号
     *
     * @return smb主单号
     */
    RemoteResult<List<String>> getSmbThrowCustomerOrderCodes(String env);


    /**
     * 获取smb支付信息，主单号
     *
     * @return 主单号
     */
    RemoteResult<List<Long>> getSmbPayInfoOrderIds(String env);



    void throwSmbOrderByCustomerOrderCodeList(List<String> customerOrderCodes);

    /**
     * 根据smb订单号 抛送订单
     *
     * @param customerOrderCode
     * @return
     */
    RemoteResult throwSmbOrderByCustomerOrderCode(String customerOrderCode);


    /**
     * 根据订单号抛smb支付信息
     *
     * @param orderIds
     * @return
     */
    void throwSmbPayInfoByOrderIdList(List<Long> orderIds);

    /**
     * 根据订单号抛smb支付信息
     *
     * @param orderId
     * @return
     */
    RemoteResult throwSmbPayInfoByOrderId(Long orderId);

}
