package com.lenovo.m2.hsbuy.job.remote.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.job.common.order.enums.ResultMessageEnum;
import com.lenovo.m2.hsbuy.job.common.order.utils.RemoteResultFactory;
import com.lenovo.m2.hsbuy.job.remote.HsLogisticsSyncRemote;
import com.lenovo.m2.hsbuy.logistics.HsLogisticsSyncTaskService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/11/29 16:06
 */
@Service
public class HsLogisticsSyncRemoteImpl implements HsLogisticsSyncRemote {
    private final static Logger LOGGER = LogManager.getLogger();

    @Autowired
    private HsLogisticsSyncTaskService hsLogisticsSyncTaskService;


    @Override
    public RemoteResult hsLogisticsSyncTask() {
        try {
             hsLogisticsSyncTaskService.hsLogisticsSyncTask();
             return RemoteResultFactory.getSuccessResult();
        } catch(Exception e) {
            LOGGER.error("hsLogisticsSyncTask error 调用soa服务异常", e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "调用soa服务异常");
        }
    }
}
