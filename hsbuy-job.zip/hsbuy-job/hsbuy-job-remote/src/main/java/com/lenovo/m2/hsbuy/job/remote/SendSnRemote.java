package com.lenovo.m2.hsbuy.job.remote;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import java.util.List;
import com.lenovo.m2.hsbuy.domain.throwengine.SmbSendSn;
/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/12/21 13:59
 */
public interface SendSnRemote {

    /**
     * 默认获取并保存（ 前一个小时，到当前小时）的smb的sn 数据
     *
     * @return
     */
    RemoteResult getAndSaveSmbSn();


    /**
     * 获取待send 的sn
     *
     * @param env
     * @return
     */
    RemoteResult<List<SmbSendSn>> querySmbSn(String env);


    /**
     * 同步 sn
     * @param smbSendSn
     * @return
     */
    RemoteResult sendSn(SmbSendSn smbSendSn);
}
