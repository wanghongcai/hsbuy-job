package com.lenovo.m2.hsbuy.job.remote;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/11/29 16:06
 */
public interface HsLogisticsSyncRemote {


    /**
     * 惠商地址同步
     *
     * @return
     */
    RemoteResult hsLogisticsSyncTask();
}
