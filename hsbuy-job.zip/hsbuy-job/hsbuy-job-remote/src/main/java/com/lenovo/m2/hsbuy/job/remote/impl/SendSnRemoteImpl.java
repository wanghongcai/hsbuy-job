package com.lenovo.m2.hsbuy.job.remote.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.job.common.order.enums.ResultMessageEnum;
import com.lenovo.m2.hsbuy.job.common.order.utils.RemoteResultFactory;
import com.lenovo.m2.hsbuy.job.remote.SendSnRemote;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.lenovo.m2.hsbuy.throwengine.SendSnService;
import java.util.List;
import com.lenovo.m2.hsbuy.domain.throwengine.SmbSendSn;
/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/12/26 13:40
 */
@Service
public class SendSnRemoteImpl implements SendSnRemote {
    private final static Logger LOGGER = LogManager.getLogger();

    @Autowired
    private SendSnService sendSnService;
    /**
     * 默认获取并保存（ 前一个小时，到当前小时）的smb的sn 数据
     *
     * @return
     */
    @Override
    public RemoteResult getAndSaveSmbSn() {
        try {
            return sendSnService.getAndSaveSmbSn();
        } catch(Exception e) {
            LOGGER.error("getAndSaveSmbSn error 调用soa服务异常", e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "调用soa服务异常");
        }
    }



    /**
     * 获取待send 的sn
     *
     * @param env
     * @return
     */
    @Override
    public RemoteResult querySmbSn(String env) {
        try {
            return sendSnService.querySmbSn(env);
        } catch(Exception e) {
            LOGGER.error("querySmbSn error 调用soa服务异常", e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "调用soa服务异常");
        }
    }

    /**
     * 同步 sn
     *
     * @param smbSendSn
     * @return
     */
    @Override
    public RemoteResult sendSn(SmbSendSn smbSendSn) {
        try {
            return sendSnService.sendSn(smbSendSn);
        } catch(Exception e) {
            LOGGER.error("sendSn error 调用soa服务异常", e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "调用soa服务异常");
        }
    }
}
