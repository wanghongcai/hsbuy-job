package com.lenovo.m2.hsbuy.job.remote;

import com.lenovo.m2.arch.framework.domain.RemoteResult;


public interface MiddleWareRemote {

    /**
     * 调用中间件服务取消订单
     *
     * @param orderCode
     * @param type
     * @param shopId
     * @return
     */
    RemoteResult cancelOrder(long orderCode, int type, int shopId);
}
