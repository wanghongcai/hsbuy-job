package com.lenovo.m2.hsbuy.job.remote.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.common.middleware.RemoteResultFactory;
import com.lenovo.m2.hsbuy.common.middleware.ResultMessageEnum;
import com.lenovo.m2.hsbuy.job.remote.SmbOrderServiceRemote;
import com.lenovo.m2.hsbuy.throwengine.SmbOrderService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author licy13
 * @Date 2017/7/28
 */
@Service
public class SmbOrderServiceRemoteImpl implements SmbOrderServiceRemote {
    private final static Logger LOGGER = LogManager.getLogger();
    @Autowired
    private SmbOrderService smbOrderService;


    /**
     * 获取smb待抛单 smb单号
     *
     * @return smb主单号
     */
    @Override
    public RemoteResult getSmbThrowCustomerOrderCodes(String env) {
        try {
            return smbOrderService.getSmbThrowCustomerOrderCodes(env);
        } catch(Exception e) {
            LOGGER.error("getSmbThrowCustomerOrderCodes error", e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "调用soa服务异常");
        }
    }

    /**
     * 获取smb支付信息，主单号
     *
     * @return 主单号
     */
    @Override
    public RemoteResult getSmbPayInfoOrderIds(String env) {
        try {
            return smbOrderService.getSmbPayInfoOrderIds(env);
        } catch(Exception e) {
            LOGGER.error("getSmbPayInfoOrderIds error", e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "调用soa服务异常");
        }
    }
    
    @Override
    public void throwSmbOrderByCustomerOrderCodeList(List<String> customerOrderCodes) {
        try {
            smbOrderService.throwSmbOrderByCustomerOrderCodeList(customerOrderCodes);
        } catch(Exception e) {
            LOGGER.error("throwSmbOrderByCustomerOrderCodeList error", e);
        }
    }

    /**
     * 根据smb订单号 抛送订单
     *
     * @param customerOrderCode
     * @return
     */
    @Override
    public RemoteResult throwSmbOrderByCustomerOrderCode(String customerOrderCode) {
        try {
            LOGGER.info("throwSmbOrderByCustomerOrderCode抛送smb订单调用customerOrderCode={}",customerOrderCode);
            return smbOrderService.throwSmbOrderByCustomerOrderCode(customerOrderCode);
        } catch(Exception e) {
            LOGGER.error("throwSmbOrderByCustomerOrderCode error", e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "调用soa服务异常");
        }
    }

    /**
     * 根据订单号抛smb支付信息
     *
     * @param orderIds
     * @return
     */
    @Override
    public void throwSmbPayInfoByOrderIdList(List<Long> orderIds) {
        try {
            smbOrderService.throwSmbPayInfoByOrderIdList(orderIds);
        } catch(Exception e) {
            LOGGER.error("throwSmbPayInfoByOrderIdList error", e);
        }
    }

    /**
     * 根据订单号抛smb支付信息
     *
     * @param orderId
     * @return
     */
    @Override
    public RemoteResult throwSmbPayInfoByOrderId(Long orderId) {
        try {
            LOGGER.info("throwSmbPayInfoByOrderId抛送smb支付调用orderId={}",orderId);
            return smbOrderService.throwSmbPayInfoByOrderId(orderId);
        } catch(Exception e) {
            LOGGER.error("throwSmbPayInfoByOrderId error", e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "调用soa服务异常");
        }
    }
}
